/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Exception.hpp"

#include "Boolean.hpp"

namespace System
{
#pragma region Public Constructors

    Exception::Exception() :
        runtime_error(String::Empty)
    {
    }

    Exception::Exception(const String& message) :
        runtime_error(message)
    {
        this->message = message;
    }

    Exception::Exception(const String& message, Exception* innerException) :
        runtime_error(message)
    {
        this->message = message;
        this->innerException = innerException;
    }

#pragma endregion

#pragma region Public Destructors

    Exception::~Exception()
    {
    }

    Exception Exception::GetInnerException() const
    {
        return *innerException;
    }

    Int32 Exception::GetHResult() const
    {
        return 0;
    }

    String Exception::GetHelpLink() const
    {
        return helpURL;
    }

    void Exception::SetHelpLink(const String& value)
    {
        this->helpURL = value;
    }

    String Exception::GetSource() const
    {
        return source;
    }

    void Exception::SetSource(const String& value)
    {
        this->source = source;
    }

    Boolean Exception::Equals(const Object& obj) const
    {
        return false;
    }

    Int32 Exception::GetHashCode() const
    {
        return 0;
    }

    void Exception::SetHResult(const Int32& value)
    {
    }

#pragma endregion

    /**
     * \brief Gets a message that describes the current exception.
     * \return The error message that explains the reason for the exception, or an empty string ("").
     */
    String Exception::GetMessage() const
    {
        //if (message == null)
        //{
        //    if (className == null)
        //    {
        //        className = GetClassName();
        //    }

        //    return String("Exception was thrown in" + className);

        //}

        return message;
    }

    String Exception::ToString() const
    {
        return message;
    }

    String Exception::GetStackTrace() const
    {
        return stackTrace.ToString();
    }

    Exception Exception::GetBaseException()
    {
        return Exception();
    }

    char const* Exception::what() const
    {
        String string = ToString();
        char const* chars = static_cast<char*>(string);

        return chars;
    }

#pragma region Private Instance Methods


#pragma endregion
}
