/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

namespace System
{
    /**
     * \brief Specifies whether a DateTime object represents a local time, a Coordinated Universal Time (UTC), or is not specified 
     *        as either local time or UTC.
     */
    enum DateTimeKind
    {
        /**
         * \brief The time represented is not specified as either local time or Coordinated Universal Time (UTC).
         */
        Unspecified = 0,

        /**
         * \brief The time represented is Coordinated Universal Time (UTC).
         */
        Utc = 1,

        /**
         * \brief The time represented is local time.
         */
        Local = 2
    };
}
