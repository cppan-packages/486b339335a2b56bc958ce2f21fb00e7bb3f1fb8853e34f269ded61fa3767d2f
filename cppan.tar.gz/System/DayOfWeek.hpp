﻿/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

namespace System
{
    /**
     * \brief Specifies the day of the week.
     * \remarks The DayOfWeek enumeration represents the day of the week in calendars that have seven days per week. The value of 
     *          the constants in this enumeration ranges from DayOfWeek.Sunday to DayOfWeek.Saturday. If cast to an integer, its 
     *          value ranges from zero (which indicates DayOfWeek.Sunday) to six (which indicates DayOfWeek.Saturday).\n
     *          This enumeration is useful when it is desirable to have a strongly typed specification of the day of the week. For
     *          example, this enumeration is the type of the property value for the DateTime.DayOfWeek property.\n
     *          The members of the DayOfWeek enumeration are not localized. To return the localized name of the day of the week,
     *          call the DateTime.ToString(String) or the DateTime.ToString(String, IFormatProvider) method with either the "ddd"
     *          or "dddd" format strings. The former format string produces the abbreviated weekday name; the latter produces the
     *          full weekday name.
     */
    enum DayOfWeek
    {
        /**
         * \brief Indicates Sunday.
         */
        Sunday = 0,

        /**
        * \brief Indicates Monday.
        */
        Monday = 1,

        /**
        * \brief Indicates Tuesday.
        */
        Tuesday = 2,

        /**
        * \brief Indicates Wednesday.
        */
        Wednesday = 3,

        /**
        * \brief Indicates Thursday.
        */
        Thursday = 4,

        /**
        * \brief Indicates Friday.
        */
        Friday = 5,

        /**
        * \brief Indicates Saturday.
        */
        Saturday = 6
    };
}
