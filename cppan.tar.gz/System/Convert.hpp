/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Boolean.hpp"

namespace System
{
    class Convert final : public Object
    {
    public:

#pragma region Public Static Methods

        /**
         * \brief Casts a value of type TOriginal to the type TResult.
         * \tparam TOriginal The type of the original value.
         * \tparam TResult The type to cast the original value to.
         * \param originalValue 
         * \return 
         */
        template <typename TOriginal, typename TResult>
        static TResult& Cast(const TOriginal& originalValue);

        /**
         * \brief 
         * \tparam TOriginal 
         * \tparam TResult 
         * \param originalValue 
         * \param resultValue 
         * \return 
         */
        template <typename TOriginal, typename TResult>
        static Boolean TryCast(const TOriginal& originalValue, TResult& resultValue);

        /**
         * \brief 
         * \tparam TOriginal 
         * \tparam TResult 
         * \param originalValue 
         * \return 
         */
        template <typename TOriginal, typename TResult>
        static Boolean Is(const TOriginal& originalValue);

        template <class TResult>
        static Boolean Is(const Object& originalValue);

#pragma endregion
    };

#pragma region Public Static Methods

    template <typename TOriginal, typename TResult>
    TResult& Convert::Cast(const TOriginal& originalValue)
    {
        const TResult& resultValue = dynamic_cast<const TResult&>(originalValue);

        return const_cast<TResult&>(resultValue);
    }

    template <typename TOriginal, typename TResult>
    Boolean Convert::TryCast(const TOriginal& originalValue, TResult& resultValue)
    {
        const TResult& result = *dynamic_cast<const TResult*>(&originalValue);

        if (&result == nullptr)
        {
            return false;
        }

        resultValue = result;
        return true;
    }

    template <typename TResult>
    Boolean Convert::Is(const Object& originalValue)
    {
        const TResult& result = *dynamic_cast<const TResult*>(&originalValue);

        if (&result == nullptr)
        {
            return false;
        }

        return true;
    }

#pragma endregion
}
