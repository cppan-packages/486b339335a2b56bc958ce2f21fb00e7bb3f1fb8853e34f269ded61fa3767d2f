/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"
#include "Interface.hpp"

namespace System
{
    class Object;

    /**
     * \brief Supports cloning, which creates a new instance of a class with the same value as an existing instance.
     */
    interface DLLExport ICloneable
    {
    protected:
        ~ICloneable() = default;

    public:
        /**
         * \brief Creates a new object that is a copy of the current instance.
         * \return A new object that is a copy of this instance.
         */
        virtual Object Clone() = 0;
    };
}
