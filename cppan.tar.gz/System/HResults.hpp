/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#pragma region Forward Declarations

namespace System
{
    struct Int32;
}

#pragma endregion

namespace System
{
    class HResults final
    {
    public:

#pragma region Public Static Constants

        static const Int32 RO_E_CLOSED;
        static const Int32 E_BOUNDS;
        static const Int32 E_CHANGED_STATE;
        static const Int32 E_FAIL;
        static const Int32 E_POINTER;
        static const Int32 E_NOTIMPL;
        static const Int32 REGDB_E_CLASSNOTREG;
        static const Int32 COR_E_AMBIGUOUSMATCH;
        static const Int32 COR_E_APPDOMAINUNLOADED;
        static const Int32 COR_E_APPLICATION;
        static const Int32 COR_E_ARGUMENT;
        static const Int32 COR_E_ARGUMENTOUTOFRANGE;
        static const Int32 COR_E_ARITHMETIC;
        static const Int32 COR_E_ARRAYTYPEMISMATCH;
        static const Int32 COR_E_BADIMAGEFORMAT;
        static const Int32 COR_E_TYPEUNLOADED;
        static const Int32 COR_E_CANNOTUNLOADAPPDOMAIN;
        static const Int32 COR_E_COMEMULATE;
        static const Int32 COR_E_CONTEXTMARSHAL;
        static const Int32 COR_E_DATAMISALIGNED;
        static const Int32 COR_E_TIMEOUT;
        static const Int32 COR_E_CUSTOMATTRIBUTEFORMAT;
        static const Int32 COR_E_DIVIDEBYZERO; // DISP_E_DIVBYZERO
        static const Int32 COR_E_DUPLICATEWAITOBJECT;
        static const Int32 COR_E_EXCEPTION;
        static const Int32 COR_E_EXECUTIONENGINE;
        static const Int32 COR_E_FIELDACCESS;
        static const Int32 COR_E_FORMAT;
        static const Int32 COR_E_INDEXOUTOFRANGE;
        static const Int32 COR_E_INSUFFICIENTMEMORY;
        static const Int32 COR_E_INSUFFICIENTEXECUTIONSTACK;
        static const Int32 COR_E_INVALIDCAST;
        static const Int32 COR_E_INVALIDCOMOBJECT;
        static const Int32 COR_E_INVALIDFILTERCRITERIA;
        static const Int32 COR_E_INVALIDOLEVARIANTTYPE;
        static const Int32 COR_E_INVALIDOPERATION;
        static const Int32 COR_E_INVALIDPROGRAM;
        static const Int32 COR_E_KEYNOTFOUND;
        static const Int32 COR_E_MARSHALDIRECTIVE;
        static const Int32 COR_E_MEMBERACCESS;
        static const Int32 COR_E_METHODACCESS;
        static const Int32 COR_E_MISSINGFIELD;
        static const Int32 COR_E_MISSINGMANIFESTRESOURCE;
        static const Int32 COR_E_MISSINGMEMBER;
        static const Int32 COR_E_MISSINGMETHOD;
        static const Int32 COR_E_MISSINGSATELLITEASSEMBLY;
        static const Int32 COR_E_MULTICASTNOTSUPPORTED;
        static const Int32 COR_E_NOTFINITENUMBER;
        static const Int32 COR_E_PLATFORMNOTSUPPORTED;
        static const Int32 COR_E_NOTSUPPORTED;
        static const Int32 COR_E_NULLREFERENCE;
        static const Int32 COR_E_OBJECTDISPOSED;
        static const Int32 COR_E_OPERATIONCANCELED;
        static const Int32 COR_E_OUTOFMEMORY;
        static const Int32 COR_E_OVERFLOW;
        static const Int32 COR_E_RANK;
        static const Int32 COR_E_REFLECTIONTYPELOAD;
        static const Int32 COR_E_RUNTIMEWRAPPED;
        static const Int32 COR_E_SAFEARRAYRANKMISMATCH;
        static const Int32 COR_E_SAFEARRAYTYPEMISMATCH;
        static const Int32 COR_E_SAFEHANDLEMISSINGATTRIBUTE;
        static const Int32 COR_E_SECURITY;
        static const Int32 COR_E_SERIALIZATION;
        static const Int32 COR_E_SEMAPHOREFULL;
        static const Int32 COR_E_WAITHANDLECANNOTBEOPENED;
        static const Int32 COR_E_ABANDONEDMUTEX;
        static const Int32 COR_E_STACKOVERFLOW;
        //static const Int32 COR_E_SYNCHRONIZATIONLOCK = ((Int32)0x80131518);
        //static const Int32 COR_E_SYSTEM = ((Int32)0x80131501);
        //static const Int32 COR_E_TARGET = ((Int32)0x80131603);
        //static const Int32 COR_E_TARGETINVOCATION = ((Int32)0x80131604);
        //static const Int32 COR_E_TARGETPARAMCOUNT = ((Int32)0x8002000e);
        //static const Int32 COR_E_THREADABORTED = ((Int32)0x80131530);
        //static const Int32 COR_E_THREADINTERRUPTED = ((Int32)0x80131519);
        //static const Int32 COR_E_THREADSTATE = ((Int32)0x80131520);
        //static const Int32 COR_E_THREADSTOP = ((Int32)0x80131521);
        //static const Int32 COR_E_THREADSTART = ((Int32)0x80131525);
        //static const Int32 COR_E_TYPEACCESS = ((Int32)0x80131543);
        //static const Int32 COR_E_TYPEINITIALIZATION = ((Int32)0x80131534);
        //static const Int32 COR_E_TYPELOAD = ((Int32)0x80131522);
        //static const Int32 COR_E_ENTRYPOINTNOTFOUND = ((Int32)0x80131523);
        //static const Int32 COR_E_DLLNOTFOUND = ((Int32)0x80131524);
        //static const Int32 COR_E_UNAUTHORIZEDACCESS = ((Int32)0x80070005);
        //static const Int32 COR_E_UNSUPPORTEDFORMAT = ((Int32)0x80131523);
        //static const Int32 COR_E_VERIFICATION = ((Int32)0x8013150D);
        //static const Int32 COR_E_HOSTPROTECTION = ((Int32)0x80131640);
        //static const Int32 CORSEC_E_MIN_GRANT_FAIL = ((Int32)0x80131417);
        //static const Int32 CORSEC_E_NO_EXEC_PERM = ((Int32)0x80131418);
        //static const Int32 CORSEC_E_POLICY_EXCEPTION = ((Int32)0x80131416);
        //static const Int32 CORSEC_E_XMLSYNTAX = ((Int32)0x80131418);
        //static const Int32 NTE_FAIL = ((Int32)0x80090020);
        //static const Int32 CORSEC_E_CRYPTO = ((Int32)0x80131430);
        //static const Int32 CORSEC_E_CRYPTO_UNEX_OPER = ((Int32)0x80131431);
        //static const Int32 DISP_E_OVERFLOW = ((Int32)0x8002000a);
        //static const Int32 FUSION_E_REF_DEF_MISMATCH = ((Int32)0x80131040);
        //static const Int32 FUSION_E_INVALID_NAME = ((Int32)0x80131047);
        //static const Int32 TYPE_E_TYPEMISMATCH = ((Int32)0x80028ca0);

#pragma endregion
    };
}
