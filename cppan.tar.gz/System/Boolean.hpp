/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"

#pragma region Forward Declarations

namespace System
{
    class String;
}

#pragma endregion

namespace System
{
    /**
    * \brief Represents a Boolean (true or false) value.
    */
    struct DLLExport Boolean final : public Object
    {
    private:
        bool value;

        /**
         * \brief The true value.
         */
        static const Int32 True;


        /**
         * \brief The false value.
         */
        static const Int32 False;

    public:

#pragma region Public Constants

        /**
        * \brief Represents the Boolean value false as a string. This field is read-only.
        */
        static const String FalseString;

        /**
        * \brief Represents the Boolean value true as a string. This field is read-only.
        */
        static const String TrueString;

#pragma endregion

#pragma region Public Constructors

        Boolean();

        Boolean(bool value);

#pragma endregion

#pragma region Public Destructors

        ~Boolean();

#pragma endregion

        /**
         * \brief Converts the specified string representation of a logical value to its Boolean equivalent.
         * \param value A string containing the value to convert.
         * \return true if value is equivalent to TrueString; false if value is equivalent to FalseString.
         * \remarks The value parameter, optionally preceded or trailed by white space, must contain either TrueString or 
         *          FalseString; otherwise, an exception is thrown. The comparison is case-insensitive.
         */
        static Boolean Parse(String value);

        /**
         * \brief Tries to convert the specified string representation of a logical value to its Boolean equivalent. A return value 
         *        indicates whether the conversion succeeded or failed.
         * \param value A string containing the value to convert.
         * \param result When this method returns, if the conversion succeeded, contains true if value is equal to 
         *               Boolean.TrueString or false if value is equal to FalseString. If the conversion failed, contains false. 
         *               The conversion fails if value is null or is not equal to the value of either the TrueString or FalseString
         *               field.
         * \return true if value was converted successfully; otherwise, false.
         */
        static Boolean TryParse(String value, Boolean& result);


#pragma region Public Overrided Instance Methods

        /**
         * \brief 
         * \return 
         */
        Int32 GetHashCode() const override;

        /**
         * \brief 
         * \return 
         */
        String ToString() const override;

#pragma endregion

#pragma region Public Conversion Operators

        operator bool() const;

#pragma endregion
    };
}
