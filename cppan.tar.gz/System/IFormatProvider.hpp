/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Interface.hpp"

#pragma region Forward Declarations

namespace System
{
    class Object;
    class Type;
}

#pragma endregion

namespace System
{
    /**
     * \brief Provides a mechanism for retrieving an object to control formatting.
     */
    interface IFormatProvider
    {
    protected:
        ~IFormatProvider() = default;

    public:

        /**
         * \brief Returns an object that provides formatting services for the specified type.
         * \param formatType An object that specifies the type of format object to return.
         * \return An instance of the object specified by formatType, if the IFormatProvider implementation can supply that type of
         *         object; otherwise, null.
         */
        virtual Object GetFormat(const Type& formatType) = 0;
    };
}
