/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"

#include "Object.hpp"
#include "IComparable.hpp"
#include "IEquatable.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Boolean;
    struct Double;

    class ArgumentException;
}

namespace System::Globalization
{
    class CultureInfo;
    enum UnicodeCategory;
}

#pragma endregion

namespace System
{
    /**
     * \brief Represents a Character as a UTF-16 code unit.
     */
    struct DLLExport Char final : public Object, IComparable<>, IComparable<Char>, IEquatable<Char>
    {
    public:

#pragma region Public Constants

        /**
         * \brief Represents the largest possible value of a Char. This field is constant.
         */
        static const Char MaxValue;

        /**
         * \brief Represents the smallest possible value of a Char. This field is constant.
         */
        static const Char MinValue;

#pragma endregion

#pragma region Public Constructors

        Char();

        Char(char value);

#pragma endregion

        ~Char() override;

#pragma region  Public Static Methods

        //static String ConvertFromUtf32(Int32 utf32);

        //static Int32 ConvertToUtf32(Char highSurrogate, Char lowSurrogate);

        //static Int32 ConvertToUtf32(String s, Int32 index);

        //static Double GetNumericValue(Char c);

        //static Double GetNumericValue(String s, Int32 index);

        //static Globalization::UnicodeCategory GetUnicodeCategory(Char c);

        //static Globalization::UnicodeCategory GetUnicodeCategory(String s, Int32 index);

        //static Boolean IsControl(Char c);

        //static Boolean IsControl(String s, Int32 index);

        //static Boolean IsDigit(Char c);

        //static Boolean IsDigit(String s, Int32 index);

        //static Boolean IsHighSurrogate(Char c);

        //static Boolean IsHighSurrogate(String s, Int32 index);

        //static Boolean IsLetter(Char c);

        //static Boolean IsLetter(String s, Int32 index);

        //static Boolean IsLetterOrDigit(Char c);

        //static Boolean IsLetterOrDigit(String s, Int32 index);

        //static Boolean IsLower(Char c);

        //static Boolean IsLower(String s, Int32 index);

        //static Boolean IsLowSurrogate(Char c);

        //static Boolean IsLowSurrogate(String s, Int32 index);

        //static Boolean IsNumber(Char c);

        //static Boolean IsNumber(String s, Int32 index);

        //static Boolean IsPunctuation(Char c);

        //static Boolean IsPunctuation(String s, Int32 index);

        //static Boolean IsSeparator(Char c);

        //static Boolean IsSeparator(String s, Int32 index);

        //static Boolean IsSurrogate(Char c);

        //static Boolean IsSurrogate(String s, Int32 index);

        //static Boolean IsSurrogatePair(Char highSurrogate, Char lowSurrogate);

        //static Boolean IsSurrogatePair(String s, Int32 index);

        //static Boolean IsSymbol(Char c);

        //static Boolean IsSymbol(String s, Int32 index);

        //static Boolean IsUpper(Char c);

        //static Boolean IsUpper(String s, Int32 index);

        static Boolean IsWhiteSpace(const Char c);

        //static Boolean IsWhiteSpace(String s, Int32 index);

        //static Char Parse(String s);

        //static Char ToLower(Char c);

        //static Char ToLower(Char c, Globalization::CultureInfo culture);

        //static Char ToLowerInvariant(Char c);

        //static String ToString(Char c);

        //static Char ToUpper(Char c);

        //static Char ToUpper(Char c, Globalization::CultureInfo culture);

        //static Char ToUpperInvariant(Char c);

        //static Boolean TryParse(String s, Char& result);

#pragma endregion

#pragma region Public Overrided Instance Methods

        /**
         * \brief Compares this instance to a specified object and indicates whether this instance precedes, follows, or appears in
         *        the same position in the sort order as the specified Object.
         * \param other An object to compare this instance to, or null.
         * \return A signed number indicating the position of this instance in the sort order in relation to the value parameter.
         * \exception ArgumentException value is not a Char object.
         */
        Int32 CompareTo(const Object& other) const override;

        /**
         * \brief Compares this instance to a specified Char object and indicates whether this instance precedes, follows, or
         *        appears in the same position in the sort order as the specified Char object.
         * \param other A Char object to compare.
         * \return A signed number indicating the position of this instance in the sort order in relation to the value parameter.
         */
        Int32 CompareTo(const Char& other) const override;

        /**
         * \brief Returns a value that indicates whether this instance is equal to a specified object.
         * \param obj An object to compare with this instance or null.
         * \return true if obj is an instance of Char and equals the value of this instance; otherwise, false.
         */
        Boolean Equals(const Object& obj) const override;

        /**
         * \brief Returns a value that indicates whether this instance is equal to the specified Char object.
         * \param other An object to compare to this instance.
         * \return true if the obj parameter equals the value of this instance; otherwise, false.
         */
        Boolean Equals(const Char& other) const override;

        /**
         * \brief 
         * \return 
         */
        Int32 GetHashCode() const override;

        /**
         * \brief 
         * \return 
         */
        String ToString() const override;

#pragma endregion

        Boolean operator==(const Char value) const;
        Boolean operator<=(const Char value) const;
        Boolean operator>=(const Char value) const;

    private:
        char value;

        static Boolean IsLatin1(const Char value);

        static Boolean IsWhiteSpaceLatin1(const Char value);
    };
}
