/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"
#include "Array.hpp"

#include <cstdint>

#pragma region Forward Declarations

namespace System
{
    struct Int32;
    struct Int64;
    typedef uint64_t UInt64;
    struct Double;

    enum DatePart;
    enum DateTimeKind;
    enum DayOfWeek;
}

#pragma endregion

namespace System
{
    /**
     * \brief Represents an instant in time, typically expressed as a date and time of day.
     */
    struct DateTime final : public Object
    {
    public:

#pragma region Public Constants

        /**
         * \brief Represents the largest possible value of DateTime. This field is read-only.
         */
        static const DateTime MaxValue;

        /**
         * \brief Represents the smallest possible value of DateTime. This field is read-only.
         */
        static const DateTime MinValue;

#pragma endregion

#pragma region Public Constructors

        /**
        * \brief
        */
        DateTime();

        /**
        * \brief Initializes a new instance of the DateTime structure to a specified number of ticks.
        * \param ticks A date and time expressed in the number of 100-nanosecond intervals that have elapsed since January 1, 0001 
        *              at 00:00:00.000 in the Gregorian calendar.
        */
        DateTime(const Int64& ticks);

        /**
         * \brief Initializes a new instance of the DateTime structure to a specified number of ticks and to Coordinated Universal
         *        Time (UTC) or local time.
         * \param ticks A date and time expressed in the number of 100-nanosecond intervals that have elapsed since January 1, 0001
         *              at 00:00:00.000 in the Gregorian calendar.
         * \param kind One of the enumeration values that indicates whether ticks specifies a local time, Coordinated Universal
         *             Time (UTC), or neither.
         */
        DateTime(const Int64& ticks, const DateTimeKind& kind);

        /**
         * \brief Initializes a new instance of the DateTime structure to the specified year, month, and day.
         * \param year The year (1 through 9999).
         * \param month The month (1 through 12).
         * \param day The day (1 through the number of days in month).
         */
        DateTime(const Int32& year, const Int32& month, const Int32& day);

        /**
         * \brief Initializes a new instance of the DateTime structure to the specified year, month, day, hour, minute, and second.
         * \param year The year (1 through 9999).
         * \param month The month (1 through 12).
         * \param day The day (1 through the number of days in month).
         * \param hour The hours (0 through 23).
         * \param minute The minutes (0 through 59).
         * \param second The seconds (0 through 59).
         */
        DateTime(const Int32& year, const Int32& month, const Int32& day, const Int32& hour, const Int32& minute,
                 const Int32& second);

        /**
        * \brief Initializes a new instance of the DateTime structure to the specified year, month, day, hour, minute, second, and
        *        millisecond.
        * \param year The year (1 through 9999).
        * \param month The month (1 through 12).
        * \param day The day (1 through the number of days in month).
        * \param hour The hours (0 through 23).
        * \param minute The minutes (0 through 59).
        * \param second The seconds (0 through 59).
        * \param millisecond The milliseconds (0 through 999).
        */
        DateTime(const Int32& year, const Int32& month, const Int32& day, const Int32& hour, const Int32& minute,
                 const Int32& second, const Int32& millisecond);

#pragma endregion

#pragma region Public Static Methods

        /**
         * \brief
         * \param year
         * \return
         */
        static Boolean IsLeapYear(const Int32& year);

        /**
         * \brief
         * \param year
         * \param month
         * \return
         */
        static Int32 DaysInMonth(const Int32& year, const Int32& month);

#pragma endregion

#pragma region Public Static Properties

        //static DateTime GetNow();

        static DateTime GetUtcNow();

        static Int64 GetSystemTime();

#pragma endregion

#pragma region Public Instnace Properties

        /**
        * \brief Gets the day of the month represented by this instance.
        * \return The day component, expressed as a value between 1 and 31.
        */
        ReadonlyProperty(Int32, Day);
        Get(Day) const;

        /**
         * \brief Gets the day of the week represented by this instance.
         * \return An enumerated constant that indicates the day of the week of this DateTime value.
         */
        DayOfWeek GetDayOfWeek() const;

        /**
         * \brief Gets the day of the year represented by this instance.
         * \return The day of the year, expressed as a value between 1 and 366.
         * \remark TheDayOfYear property takes leap years into account when it calculates the day of the year. The property value 
         *         always reflects the day of the year in the Gregorian calendar, regardless of the current thread culture's 
         *         current calendar. To retrieve the day of the year in a different calendar, call the Calendar.GetDayOfYear 
         *         method of that calendar.
         */
        ReadonlyProperty(Int32, DayOfYear);
        Get(DayOfYear) const;

        /**
         * \brief Gets the hour component of the date represented by this instance.
         * \return The hour component, expressed as a value between 0 and 23.
         */
        ReadonlyProperty(Int32, Hour);
        Get(Hour) const;

        /**
         * \brief Gets the milliseconds component of the date represented by this instance.
         * \return The milliseconds component, expressed as a value between 0 and 999.
         */
        Int32 GetMillisecond() const;

        /**
         * \brief Gets the minute component of the date represented by this instance.
         * \return The minute component, expressed as a value between 0 and 59.
         */
        Int32 GetMinute() const;

        /**
         * \brief Gets the month component of the date represented by this instance.
         * \return The month component, expressed as a value between 1 and 12.
         */
        Int32 GetMonth() const;

        /**
         * \brief 
         * \return 
         */
        Int32 GetSecond() const;

        /**
         * \brief 
         * \return 
         */
        Int32 GetYear() const;

        /**
         * \brief Gets the number of ticks that represent the date and time of this instance.
         * \return The number of ticks that represent the date and time of this instance. The value is between
         *         DateTime.MinValue.Ticks and DateTime.MaxValue.Ticks.
         */
        Int64 GetTicks() const;

#pragma endregion

#pragma region Public Instance Methods

        /**
         * \brief Returns a new DateTime that adds the specified number of ticks to the value of this instance.
         * \param value A number of 100-nanosecond ticks. The value parameter can be positive or negative.
         * \return An object whose value is the sum of the date and time represented by this instance and the time represented by 
         *         value.
         */
        DateTime AddTicks(const Int64& value) const;

#pragma endregion

#pragma region Public Overriden Instance Methods

        String ToString() const override final;

#pragma endregion

    private:

#pragma region Private Static Variables

        static const Int32 MinMillisecond;
        static const Int32 MaxMilisecond;
        static const Int32 MinSecond;
        static const Int32 MaxSecond;
        static const Int32 MinMinute;
        static const Int32 MaxMinute;
        static const Int32 MinHour;
        static const Int32 MaxHour;
        static const Int32 MinDay;
        static const Int32 MaxDay;
        static const Int32 MinMonth;
        static const Int32 MaxMonth;
        static const Int32 MinYear;
        static const Int32 MaxYear;

        // Number of 100ns ticks per time unit.
        static const Int64 TicksPerMillisecond;
        static const Int64 TicksPerSecond;
        static const Int64 TicksPerMinute;
        static const Int64 TicksPerHour;
        static const Int64 TicksPerDay;

        // Number of milliseconds per time unit.
        static const Int32 MillisecondsPerSecond;
        static const Int32 MillisecondsPerMinute;
        static const Int32 MillisecondsPerHour;

        /**
        * \brief The number of milliseconds per day.
        */
        static const Int32 MillisecondsPerDay;

        static const Int32 SecondsPerMinute;
        static const Int32 MinutesPerHour;
        static const Int32 HoursPerDay;

        // Number of days per number of years. 

        /**
         * \brief The number of days in a week.
         */
        static const Int32 DaysPerWeek;

        /**
        * \brief The number of days in a non-leap year.
        */
        static const Int32 DaysPerYear;

        /**
        * \brief The number of days in a leap year.
        */
        static const Int32 DaysPerLeapYear;

        /**
        * \brief The number of days in 4 years.
        */
        static const Int32 DaysPer4Years;

        /**
        * \brief The number of days in 100 years.
        */
        static const Int32 DaysPer100Years;

        /**
        * \brief The number of days in 400 years.
        */
        static const Int32 DaysPer400Years;

        // Number of days to year.

        /**
        * \brief The number of days from 1/1/0001 to 12/31/1600.
        */
        static const Int32 DaysTo1601;

        /**
        * \brief The number of days from 1/1/0001 to 12/30/1899.
        */
        static const Int32 DaysTo1899;

        /**
        * \brief Number of days from 1/1/0001 to 12/31/1969.
        */
        static const Int32 DaysTo1970;

        /**
        * \brief The number of days from 1/1/0001 to 12/31/9999.
        */
        static const Int32 DaysTo10000;

        //

        static const Int64 MinTicks;
        static const Int64 MaxTicks;
        static const Int64 MaxMillisecond;

        // OLE Automation (OA) Dates.

        static const Int64 FileTimeOffset;
        static const Int64 DoubleDateOffset;

        /**
        * \brief The minimum OLE Automation (OA) date is 0100/01/01 (Note it's year 100). The maximum OA date is 9999/12/31.
        */
        static const Int64 OADateMinAsTicks;

        /**
        * \brief All OLE Automation (OA) dates must be greater than (not >=) OADateMinAsDouble.
        */
        static const Double OADateMinAsDouble;

        /**
        * \brief All OLE Automation (OA) dates must be less than (not <=) OADateMaxAsDouble.
        */
        static const Double OADateMaxAsDouble;

        // Number of days to month in year.

        static const Array<Int32, 13> DaysToMonth365;
        static const Array<Int32, 13> DaysToMonth366;

        // Masks.

        static const UInt64 TicksMask;
        static const UInt64 FlagsMask;
        static const UInt64 LocalMask;
        static const Int64 TicksCeiling;
        static const UInt64 KindUnspecified;
        static const UInt64 KindUtc;
        static const UInt64 KindLocal;
        static const UInt64 KindLocalAmbiguousDst;
        static const Int32 KindShift;

        static const DateTime UnixEpoch;

        /**
        * \brief
        * \remarks The data is stored as an unsigned 64-bit integeter.
        *           - Bits 01-62: The value of 100-nanosecond ticks where 0 represents 1/1/0001 12:00am, up until the value
        *                         12/31/9999 23:59:59.9999999
        *           - Bits 63-64: A four-state value that describes the DateTimeKind value of the date time, with a 2nd
        *                         value for the rare case where the date time is local, but is in an overlapped daylight
        *                         savings time hour and it is in daylight savings time. This allows distinction of these
        *                         otherwise ambiguous local times and prevents data loss when round tripping from Local to
        *                         UTC time.
        */
        UInt64 dateData;

#pragma endregion

#pragma region Private Constructors

        /**
        * \brief
        * \param dateData
        */
        DateTime(const UInt64& dateData);

        DateTime(const Int64& ticks, const DateTimeKind& kind, const Boolean& isAmbiguousDst);

#pragma endregion

#pragma region Private Static Methods

        /**
        * \brief Returns the tick count corresponding to the given year, month, and day.\n
        *        Will check the if the parameters are valid.
        * \param year
        * \param month
        * \param day
        */
        static Int64 DateToTicks(const Int32& year, const Int32& month, const Int32& day);

        /**
        * \brief Returns the tick count corresponding to the given hour, minute, second.\n
        *        Will check the if the parameters are valid.
        * \param hour
        * \param minute
        * \param second
        * \return
        */
        static Int64 TimeToTicks(const Int32& hour, const Int32& minute, const Int32& second);

#pragma endregion

#pragma region Private Instance Methods

        Int64 GetInternalTicks() const;

        UInt64 GetInternalKind() const;

        /**
         * \brief Returns a given date part of this DateTime. This method is used to compute the year, day-of-year, month, or day
         *        part.
         * \param datePart 
         * \return 
         */
        Int32 GetDatePart(const DatePart& datePart) const;

        DateTime Add(const Double& value, const Double& scale) const;

#pragma endregion
    };


    /**
    * \brief
    */
    enum DatePart
    {
        Year = 0,
        DayOfYear = 1,
        Month = 2,
        Day = 3
    };
}
