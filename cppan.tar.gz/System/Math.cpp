/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Math.hpp"

#include "Boolean.hpp"
#include "Byte.hpp"
#include "Int16.hpp"
#include "Int32.hpp"
#include "Int64.hpp"
#include "Single.hpp"
#include "Double.hpp"

#include <complex>

namespace System
{
#pragma region Public Constants

    const Double Math::E = 2.7182818284590451;
    const Double Math::PI = 3.1415926535897931;

#pragma endregion

#pragma region Public Static Methods

#pragma region Absolutes

    Double Math::Abs(const Double& value)
    {
        return std::abs(value);
    }

    Int16 Math::Abs(Int16 value)
    {
        return std::abs(value);
    }

    Int32 Math::Abs(Int32 value)
    {
        return std::abs(value);
    }

    Int64 Math::Abs(Int64 value)
    {
        return std::abs(value);
    }

    Single Math::Abs(Single value)
    {
        return std::abs(value);
    }

#pragma endregion

    Double Math::Acos(Double d)
    {
        return std::acos(d);
    }

    Double Math::Asin(Double d)
    {
        return std::asin(d);
    }

    Double Math::Atan(Double d)
    {
        return std::atan(d);
    }

    Double Math::Atan2(Double y, Double x)
    {
        return std::atan2(y, x);
    }

    Int64 Math::BigMul(const Int32& a, const Int32& b)
    {
        return Int64(a) * b;
    }

#pragma region Cosines

    Double Math::Cos(const Double& d)
    {
        return std::cos(d);
    }

    Double Math::Cosh(Double value)
    {
        return std::cosh(value);
    }

    Int32 Math::DivRem(const Int32& a, const Int32& b, Int32& result)
    {
        Int32 div = a / b;
        result = a - (div * b);

        return div;
    }

#pragma endregion

    Double Math::Log(Double d)
    {
        return std::log(d);
    }

    Double Math::Log(const Double& a, const Double& newBase)
    {
        // IEEE 754-2008: NaN payload must be preserved.
        if (Double::IsNaN(a))
        {
            return a;
        }

        // IEEE 754-2008: NaN payload must be preserved.
        if (Double::IsNaN(newBase))
        {
            return newBase;
        }

        if (newBase == 1)
        {
            return Double::NaN;
        }

        if (a != 1 && (newBase == 0 || Double::IsPositiveInfinity(newBase)))
        {
            return Double::NaN;
        }

        return Log(a) / Log(newBase);
    }

    Double Math::Log10(Double d)
    {
        return std::log10(d);
    }

    Byte Math::Max(Byte val1, Byte val2)
    {
        return (val1 >= val2) ? val1 : val2;
    }

    Double Math::Pow(Double x, Double y)
    {
        return std::pow(x, y);
    }

    Int32 Math::Sign(const Int32& value)
    {
        if (value < 0)
        {
            return -1;
        }

        if (value > 0)
        {
            return 1;
        }

        return 0;
    }

    Double Math::Sin(Double a)
    {
        return std::sin(a);
    }

    Double Math::Sinh(Double value)
    {
        return std::sinh(value);
    }

    Double Math::Sqrt(Double d)
    {
        return std::sqrt(d);
    }

    Double Math::Tan(const Double& a)
    {
        return std::tan(a);
    }

    Double Math::Tanh(const Double& value)
    {
        return std::tanh(value);
    }

#pragma endregion

#pragma region Private Constructor

    Math::Math()
    {
    }

#pragma endregion

#pragma region Private Destructor

    Math::~Math()
    {
    }

#pragma endregion
}
