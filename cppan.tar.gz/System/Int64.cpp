/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Int64.hpp"

#include "String.hpp"

#include <cstdint>
#include <string>

namespace System
{
#pragma region Constants

    const Int64 Int64::MaxValue = std::numeric_limits<int64_t>().max();
    const Int64 Int64::MinValue = std::numeric_limits<int64_t>().min();

#pragma endregion

#pragma region Public Constructors

    Int64::Int64(int64_t value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Destructors

    Int64::~Int64()
    {
    }

#pragma endregion

#pragma region Public Overrided Instance Methods

    String Int64::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion

    //Int64 Int64::operator+(const Int64& rhs)
    //{
    //    this->value += rhs;
    //    return this->value;
    //}

    //Int64 Int64::operator-(const Int64& rhs)
    //{
    //    this->value -= rhs;
    //    return this->value;
    //}

    //Int64 Int64::operator*(const Int64& rhs)
    //{
    //    this->value *= rhs;
    //    return this->value;
    //}

    //Int64 Int64::operator/(const Int64& rhs)
    //{
    //    this->value /= rhs;
    //    return this->value;
    //}

    Int64& Int64::operator+=(const Int64& rhs)
    {
        this->value = this->value + rhs.value;
        return *this;
    }

    Int64& Int64::operator-=(const Int64& rhs)
    {
        this->value = this->value - rhs.value;
        return *this;
    }

    Int64& Int64::operator*=(const Int64& rhs)
    {
        this->value = this->value * rhs.value;
        return *this;
    }

    Int64& Int64::operator/=(const Int64& rhs)
    {
        this->value = this->value / rhs.value;
        return *this;
    }

    Int64& Int64::operator++()
    {
        this->value += 1;
        return *this;
    }

    Int64 Int64::operator++(int) const
    {
        return this->value + 1;
    }

#pragma region Public Conversion Operators

    Int64::operator int64_t() const
    {
        return value;
    }

#pragma endregion
}
