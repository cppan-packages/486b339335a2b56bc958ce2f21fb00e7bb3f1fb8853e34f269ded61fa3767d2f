/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"
#include "Object.hpp"

namespace System
{
    /**
     * \brief Represents a double-precision floating-point number.
     */
    struct DLLExport Double final : public Object
    {
    public:

#pragma region  Public Constants

        /**
         * \brief Represents the smallest positive Double value that is greater than zero. This field is constant.
         */
        static const Double Epsilon;

        /**
         * \brief Represents the largest possible value of a Double. This field is constant.
         */
        static const Double MaxValue;

        /**
         * \brief Represents the smallest possible value of a Double. This field is constant.
         */
        static const Double MinValue;

        /**
         * \brief Represents a value that is not a number (NaN). This field is constant.
         */
        static const Double NaN;

        /**
         * \brief Represents negative infinity. This field is constant.
         */
        static const Double NegativeInfinity;

        /**
         * \brief Represents positive infinity. This field is constant.
         */
        static const Double PositiveInfinity;

#pragma endregion

#pragma region Public Constructors

        Double();

        Double(double value);

#pragma endregion

#pragma region Public Destructors

        ~Double();

#pragma endregion

#pragma region Public Static Methods

        /**
        * \brief Returns a value indicating whether the specified number evaluates to negative or positive infinity
        * \param d A double-precision floating-point number.
        * \return true if d evaluates to PositiveInfinity or NegativeInfinity; otherwise, false.
        */
        static Boolean IsInfinity(const Double& d);

        /**
         * \brief Returns a value indicating whether the specified number evaluates to positive infinity.
         * \param d A double-precision floating-point number.
         * \return true if d evaluates to PositiveInfinity; otherwise, false.
         */
        static Boolean IsPositiveInfinity(const Double& d);

        /**
         * \brief Returns a value indicating whether the specified number evaluates to negative infinity.
         * \param d A double-precision floating-point number.
         * \return true if d evaluates to NegativeInfinity; otherwise, false.
         */
        static Boolean IsNegativeInfinity(const Double& d);

        /**
         * \brief Returns a value that indicates whether the specified value is not a number (NaN).
         * \param d A double-precision floating-point number.
         * \return true if d evaluates to NaN; otherwise, false.
         */
        static Boolean IsNaN(const Double& d);

#pragma endregion

#pragma region Public Overrided Methods

        /**
         * \brief Converts the numeric value of this instance to its equivalent string representation.
         * \return The string representation of the value of this instance.
         */
        String ToString() const override final;

#pragma endregion

#pragma region Public Operators

        Double& operator+=(const Double& rhs);
        Double& operator-=(const Double& rhs);
        Double& operator*=(const Double& rhs);
        Double& operator/=(const Double& rhs);

#pragma endregion

#pragma region Public Convertsion Operators

        operator double() const;

#pragma endregion

    private:
        double value;
    };
}
