/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "ArgumentException.hpp"

namespace System
{
#pragma region Public Constructors

    ArgumentException::ArgumentException() :
        SystemException()
    {
    }

    ArgumentException::ArgumentException(const String& message) :
        SystemException(message)
    {
    }

    ArgumentException::ArgumentException(const String& message, Exception* innerException) :
        SystemException(message, innerException)
    {
    }

    ArgumentException::ArgumentException(const String& message, const String& paramName) :
        SystemException(message)
    {
    }

    ArgumentException::ArgumentException(const String& message, const String& paramName, Exception* innerException) :
        SystemException(message, innerException)
    {
    }

#pragma endregion

#pragma region Public Virtual Instance Properties

    String ArgumentException::GetParamName() const
    {
        return paramName;
    }

#pragma endregion
}
