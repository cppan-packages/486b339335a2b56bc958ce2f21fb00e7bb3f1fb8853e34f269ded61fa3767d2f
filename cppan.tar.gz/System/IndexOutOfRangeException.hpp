/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "SystemException.hpp"

#pragma region Forward Declarations

namespace System
{
    class String;
}

#pragma endregion

namespace System
{
    class IndexOutOfRangeException final : public SystemException
    {
    public:

#pragma region Public Constructors

        /**
         * \brief 
         */
        explicit IndexOutOfRangeException();

        /**
         * \brief 
         * \param message 
         */
        explicit IndexOutOfRangeException(const String& message);

        /**
         * \brief 
         * \param message 
         * \param innerException 
         */
        explicit IndexOutOfRangeException(const String& message, Exception* innerException);

#pragma endregion
    };
}
