/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Int32.hpp"

#include "String.hpp"
#include "Boolean.hpp"

#include "Exception.hpp"
#include "Console.hpp"
#include "Convert.hpp"

namespace System
{
#pragma region Public Constants

    const Int32 Int32::MaxValue = std::numeric_limits<int32_t>().max();

    const Int32 Int32::MinValue = std::numeric_limits<int32_t>().min();

#pragma endregion

#pragma region Public Constructors

    Int32::Int32()
    {
        Int32(0);
    }

    Int32::Int32(int32_t value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Destructor

    Int32::~Int32()
    {
    }

#pragma endregion

#pragma region Public Overrrided Instance Methods

    Int32 Int32::CompareTo(const Object& other) const
    {
        if (&other == nullptr)
        {
            return 1;
        }

        Int32 i;
        if (!Convert::TryCast<Object, Int32>(other, i))
        {
            throw Exception("ArgumentException: Object must be an Int32.");
        }

        // Need to use compare because subtraction will wrap
        // to positive for very large neg numbers, etc.
        if (this->value < i)
        {
            return -1;
        }
        if (this->value > i)
        {
            return 1;
        }
        return 0;
    }

    Int32 Int32::CompareTo(const Int32& other) const
    {
        // Need to use compare because subtraction will wrap
        // to positive for very large neg numbers, etc.
        if (this->value < other)
        {
            return -1;
        }
        if (this->value > other)
        {
            return 1;
        }
        return 0;
    }

    Boolean Int32::Equals(const Int32& value) const
    {
        return this->value == value.value;
    }

    Boolean Int32::Equals(const Object& obj) const
    {
        return false;
    }

    Int32 Int32::GetHashCode() const
    {
        return value;
    }

    String Int32::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion

#pragma region Public Operators

    //Int32 Int32::operator+(const Int32& rhs)
    //{
    //    this->value += rhs;
    //    return this->value;
    //}

    //Int32 Int32::operator-(const Int32& rhs)
    //{
    //    this->value -= rhs;
    //    return this->value;
    //}

    //Int32 Int32::operator*(const Int32& rhs)
    //{
    //    this->value *= rhs;
    //    return this->value;
    //}

    //Int32 Int32::operator/(const Int32& rhs)
    //{
    //    this->value /= rhs;
    //    return this->value;
    //}

    Int32& Int32::operator+=(const Int32& rhs)
    {
        this->value = this->value + rhs.value;
        return *this;
    }

    Int32& Int32::operator-=(const Int32& rhs)
    {
        this->value = this->value - rhs.value;
        return *this;
    }

    Int32& Int32::operator*=(const Int32& rhs)
    {
        this->value = this->value * rhs.value;
        return *this;
    }

    Int32& Int32::operator/=(const Int32& rhs)
    {
        this->value = this->value / rhs.value;
        return *this;
    }

    Int32& Int32::operator++()
    {
        this->value += 1;
        return *this;
    }

    Int32 Int32::operator++(int) const
    {
        return this->value + 1;
    }

#pragma endregion

#pragma region Public Conversion Operators

    Int32::operator int32_t() const
    {
        return value;
    }

#pragma endregion
}
