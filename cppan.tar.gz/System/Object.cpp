/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Object.hpp"

#include "Boolean.hpp"
#include "Int32.hpp"
#include "String.hpp"

namespace System
{
#pragma region Public Constructors

    Object::Object()
    {
    }

#pragma endregion

#pragma region Public Virtual Destructor

    Object::~Object()
    {
    }

#pragma endregion

#pragma region Public Static Methods

    Boolean Object::Equals(const Object& objA, const Object& objB)
    {
        return objA.Equals(objB);
    }

#pragma endregion

#pragma region Public Virtual Instance Methods

    /**
    * \brief Determines whether the specified object is equal to the current object.
    * \param obj The object to compare with the current object.
    * \return true if the specified object is equal to the current object; otherwise, false.
    */
    Boolean Object::Equals(const Object& obj) const
    {
        return this == &obj;
    }

    Int32 Object::GetHashCode() const
    {
        return 0;
    }

    String Object::ToString() const
    {
        return typeid(this).name();
    }

#pragma endregion

#pragma region Public Operators

    bool Object::operator==(const Object& obj)
    {
        return Equals(const_cast<Object&>(obj));
    }

#pragma endregion

    Object::operator String() const
    {
        return ToString();
    }
}
