/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Debug.hpp"

#include "../Boolean.hpp"
#include "../String.hpp"
#include "../Console.hpp"

namespace System::Diagnostics
{
#pragma region Public Static Methods

    void Debug::Assert(const Boolean condition)
    {
        Assert(condition, String::Empty, String::Empty);
    }

    void Debug::Assert(const Boolean condition, const String& message)
    {
        Assert(condition, message, String::Empty);
    }

    void Debug::Assert(const Boolean condition, const String& message, const String& detailMessage)
    {
        if (condition)
        {
            return;
        }

        if (String::IsNullOrWhiteSpace(message))
        {
            Console::WriteLine("Assertion failed!");
        }
        else
        {
            Console::WriteLine(message + "\n" + detailMessage);
        }
    }

#pragma endregion
}
