/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#pragma region Forward Declarations

namespace System
{
    class Object;

    struct Boolean;
    class String;
}

#pragma endregion

namespace System::Diagnostics
{
    /**
     * \brief Provides a set of methods and properties that help debug your code.
     */
    class Debug final
    {
    public:

#pragma region Public Static Methods

        /**
         * \brief Checks for a condition; if the condition is false, displays a message box that shows the call stack.
         * \param condition The conditional expression to evaluate. If the condition is true, a failure message is not sent and the
         *                  message box is not displayed.
         */
        static void Assert(const Boolean condition);

        /**
         * \brief Checks for a condition; if the condition is false, outputs a specified message and displays a message box that
         *        shows the call stack.
         * \param condition The conditional expression to evaluate. If the condition is true, the specified message is not sent and 
         *                  the message box is not displayed.
         * \param message The message to send to the Listeners collection.
         */
        static void Assert(const Boolean condition, const String& message);

        /**
         * \brief Checks for a condition; if the condition is false, outputs two specified messages and displays a message box that
         *        shows the call stack.
         * \param condition The conditional expression to evaluate. If the condition is true, the specified messages are not sent 
         *                  and the message box is not displayed.
         * \param message The message to send to the Listeners collection.
         * \param detailMessage The detailed message to send to the Listeners collection.
         */
        static void Assert(const Boolean condition, const String& message, const String& detailMessage);

#pragma endregion
    };
}
