/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "SystemException.hpp"

#pragma region Forward Declarations

namespace System
{
    class String;
}
#pragma endregion

namespace System
{
    /**
     * \brief The exception that is thrown when one of the arguments provided to a method is not valid.
     */
    class DLLExport ArgumentException : public SystemException
    {
    public:

#pragma region Public Constructors

        /**
         * \brief Initializes a new instance of the ArgumentException class.
         */
        explicit ArgumentException();

        /**
         * \brief Initializes a new instance of the ArgumentException class with a specified error message.
         * \param message The error message that explains the reason for the exception.
         */
        explicit ArgumentException(const String& message);

        /**
         * \brief 
         * \param message 
         * \param innerException 
         */
        explicit ArgumentException(const String& message, Exception* innerException);

        /**
         * \brief 
         * \param message 
         * \param paramName 
         */
        explicit ArgumentException(const String& message, const String& paramName);

        /**
         * \brief 
         * \param message 
         * \param paramName 
         * \param innerException 
         */
        explicit ArgumentException(const String& message, const String& paramName, Exception* innerException);

#pragma endregion

#pragma region Public Virtual Instance Properties

        virtual String GetParamName() const;

#pragma endregion

#pragma region Public Overriden Instance Properties

        //String GetMessage() const override;

        //override void GetObjectData(SerializationInfo info, StreamingContext context);

#pragma endregion

    protected:

#pragma region Protected Constructors

        //ArgumentException(SerializationInfo info, StreamingContext context);

#pragma endregion

    private:

#pragma region Private Instance Variables

        String paramName;

#pragma endregion
    };
}
