/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Int16.hpp"

#include "Boolean.hpp"
#include "Int32.hpp"
#include "String.hpp"

#include <limits>
#include <string>

namespace System
{
#pragma region Public Constants

    const Int16 Int16::MaxValue = std::numeric_limits<int16_t>().max();
    const Int16 Int16::MinValue = std::numeric_limits<int16_t>().min();

#pragma endregion

#pragma region Public Constructors

    Int16::Int16()
    {
        Int16(0);
    }

    Int16::Int16(int16_t value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Desturctor

    Int16::~Int16()
    {
    }

#pragma endregion

#pragma region Public Overrided Instance Methods

    Boolean Int16::Equals(const Int16& other) const
    {
        return value == other;
    }

    Int32 Int16::CompareTo(const Object& other) const
    {
        return 0;
    }

    Int32 Int16::CompareTo(const Int16& other) const
    {
        return 0;
    }

    String Int16::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion

#pragma region Public Conversion Operators

    Int16::operator int16_t() const
    {
        return value;
    }

#pragma endregion
}
