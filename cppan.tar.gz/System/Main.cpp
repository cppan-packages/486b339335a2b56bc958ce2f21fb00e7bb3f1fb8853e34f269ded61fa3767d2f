#include "Console.hpp"
#include "Int32.hpp"
#include "Int64.hpp"
#include "String.hpp"
#include "Single.hpp"
#include "Action.hpp"
#include "Func.hpp"
#include "Math.hpp"
#include "List.hpp"

using namespace System;
using namespace System::Collections::Generic;

void Int32_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Int32 Tests");

    Console::WriteLine("Int32 example value: " + Int32(2).ToString());
    Console::WriteLine("Int32 Min value: " + Int32::MinValue.ToString());
    Console::WriteLine("Int32 Max value: " + Int32::MaxValue.ToString()); 
}

void Int64_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Int64 Tests");

    Console::WriteLine("Int64 example value: " + Int64(874374249289038).ToString());
    Console::WriteLine("Int64 Min value: " + Int64::MinValue.ToString());
    Console::WriteLine("Int64 Max value: " + Int64::MaxValue.ToString());
}

void Single_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Single Tests");

    Console::WriteLine("Single example value: " + Single(1.0F).ToString());
    Console::WriteLine("Single Min value: " + Single::MinValue.ToString());
    Console::WriteLine("Single Max value: " + Single::MaxValue.ToString());
    Console::WriteLine("Single Epsilon value: " + Single::Epsilon.ToString());
    Console::WriteLine("Single Positive Infinity value: " + Single::PositiveInfinity.ToString());
    Console::WriteLine("Single Negative Infinity value: " + Single::NegativeInfinity.ToString());  
}

void String_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::String Tests");

    String string = "Hello World!";
    Console::WriteLine("String: " + string);
    Console::WriteLine("Length: " + string.Lenght.ToString());
}

void Action_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Action Tests");

    Action<> action = []() -> void {Console::WriteLine("Action<> says hello!"); };
    action.Invoke();

    Console::WriteLine();

    Action<Int32> action1 = [](Int32 i) -> void 
    {
        Console::WriteLine("Action<Int32> says hello!");
        Console::WriteLine("Int32: " + i.ToString());
    };
    action1.Invoke(Int32(16));

    Console::WriteLine();

    Action<Int32, Single> action2 = [](Int32 i, Single s) -> void
    {
        Console::WriteLine("Action<Int32, Single> says hello!");
        Console::WriteLine("Int32: " + i.ToString());
        Console::WriteLine("Single: " + s.ToString());
    };
    action2.Invoke(Int32(32), Single(2.8F));
}

void Func_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Func Tests");

    Func<bool> func = []() -> bool 
    {
        Console::WriteLine("Func<bool> says hello!"); 
        return true;
    };
    bool result = func.Invoke();
    Console::WriteLine("Result: " + std::to_string(result));

    Console::WriteLine();

    Func<bool, Int32> func1 = [](Int32 i) -> bool
    {
        Console::WriteLine("Func<bool, Int32> says hello!");
        Console::WriteLine("Int32: " + i.ToString());
        return true;
    };
    result = func1.Invoke(Int32(32));
    Console::WriteLine("Result: " + std::to_string(result));
}

void Math_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Math Tests");

    Console::WriteLine("Double Abs: " + Math::Abs(Double(-3.5)).ToString());
    Console::WriteLine("Cos: " + Math::Cos(-3.5).ToString());
}

void List_Tests()
{
    Console::WriteLine();
    Console::WriteLine("System::Collections::Generic::List Tests");

    List<Int64> list = List<Int64>(2);
    list.Add(1);
    list.Add(2);

    Console::WriteLine(list[0].ToString());
    Console::WriteLine(list[1].ToString());

    list.RemoveAt(1);
    list.Add(3);
    list.Add(4);
    list.Add(1);

    Console::WriteLine("After removed: " + list[1].ToString());
    Console::WriteLine("Contains 1: " + std::to_string(list.Contains(1)));
    Console::WriteLine("Contains 10: " + std::to_string(list.Contains(10)));

    Console::WriteLine("Index of 1 ([0]): " + list.IndexOf(1).ToString());
    Console::WriteLine("Index of 3 ([1]): " + list.IndexOf(3).ToString());
    Console::WriteLine("Index of 10 (-1): " + list.IndexOf(10).ToString());

    Console::WriteLine("Last Index of 1: " + list.LastIndexOf(1).ToString());

    Console::WriteLine();
    list.Reverse();
    for (int i = 0; i < list.Count; i++)
    {
        Console::WriteLine(list[i]);
    }
}

int main(int argc, char** argv)
{
    Console::WriteLine("Hello World!");

    Int32_Tests();
    Int64_Tests();
    Single_Tests();
    
    String_Tests();

    Action_Tests();
    Func_Tests();

    Math_Tests();

    List_Tests();

    system("pause");
}