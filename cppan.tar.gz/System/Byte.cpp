/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Byte.hpp"

#include "Int32.hpp"
#include "String.hpp"
#include "Convert.hpp"

#include <limits>
#include "Exception.hpp"

namespace System
{
    const Byte Byte::MaxValue = std::numeric_limits<uint8_t>::max();
    const Byte Byte::MinValue = std::numeric_limits<uint8_t>::min();

#pragma region Public Constructors

    Byte::Byte()
    {
        this->value = 0;
    }

    Byte::Byte(uint8_t value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Destructors

    Byte::~Byte()
    {
    }


#pragma endregion

#pragma region Public Overriden Instance Methods

    Boolean Byte::Equals(const Object& obj) const
    {
        Byte b;
        if (!Convert::TryCast<Object, Byte>(obj, b))
        {
            return false;
        }

        return this->value == b.value;
    }

    Boolean Byte::Equals(const Byte& other) const
    {
        return this->value == other.value;
    }

    Int32 Byte::CompareTo(const Object& other) const
    {
        if (&other == nullptr)
        {
            return 1;
        }

        Byte b;
        if (!Convert::TryCast<Object, Byte>(other, b))
        {
            throw Exception("ArgumentException");
        }

        return this->value - b.value;
    }

    Int32 Byte::CompareTo(const Byte& other) const
    {
        return this->value - other.value;
    }

    Int32 Byte::GetHashCode() const
    {
        return value;
    }

    String Byte::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion

    Boolean Byte::operator>=(const Byte& b) const
    {
        return this->value >= b.value;
    }
}
