/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Vector3.hpp"

#include "../Boolean.hpp"
#include "../Math.hpp"
#include "../Double.hpp"
#include "../String.hpp"
#include "../NotImplementedException.hpp"

namespace System::Numerics
{

#pragma region Public Constructors

    Vector3::Vector3(const Single value)
    {
        Vector3(value, value, value);
    }

    Vector3::Vector3(const Single x, const Single y, const Single z)
    {
        X = x;
        Y = y;
        Z = z;
    }

#pragma endregion Public Constructors

#pragma region Public Destructor

    Vector3::~Vector3()
    {
    }

#pragma endregion Public Destructor

#pragma region Public Static Properties

    Vector3 Vector3::GetZero()
    {
        return Vector3(0.0F, 0.0F, 0.0F);
    }

    Vector3 Vector3::GetOne()
    {
        return Vector3(1.0F, 1.0F, 1.0F);
    }

    Vector3 Vector3::GetUnitX()
    {
        return Vector3(1.0F, 0.0F, 0.0F);
    }

    Vector3 Vector3::GetUnitY()
    {
        return Vector3(0.0F, 1.0F, 0.0F);
    }

    Vector3 Vector3::GetUnitZ()
    {
        return Vector3(0.0F, 0.0F, 1.0F);
    }

#pragma endregion Public Static Properties

#pragma region Public Static Methods

    Vector3 Vector3::Abs(const Vector3 value)
    {
        return Vector3(Math::Abs(value.X), Math::Abs(value.Y), Math::Abs(value.Z));
    }

    Vector3 Vector3::Add(const Vector3 left, const Vector3 right)
    {
        return left + right;
    }

    Vector3 Vector3::Clamp(const Vector3 value1, const Vector3 min, const Vector3 max)
    {
        // This compare order is very important!
        // We must follow HLSL behavior in the case user specified min value is bigger than max value.

        Single x = value1.X;
        x = (x > max.X) ? max.X : x;
        x = (x < min.X) ? min.X : x;

        Single y = value1.Y;
        y = (y > max.Y) ? max.Y : y;
        y = (y < min.Y) ? min.Y : y;

        Single z = value1.Z;
        z = (z > max.Z) ? max.Z : z;
        z = (z < min.Z) ? min.Z : z;

        return Vector3(x, y, z);
    }

    Vector3 Vector3::Cross(const Vector3 vector1, const Vector3 vector2)
    {
        return Vector3(vector1.Y*vector2.Z - vector1.Z*vector2.Y,
                       vector1.Z*vector2.X - vector1.X*vector2.Z,
                       vector1.X*vector2.Y - vector1.Y*vector2.X);
    }

    Single Vector3::Distance(const Vector3 value1, const Vector3 value2)
    {
        Vector3 difference = value1 - value2;
        Single ls = Vector3::Dot(difference, difference);

        return Single(Math::Sqrt(Double(ls)));
    }

    Single Vector3::DistanceSquared(const Vector3 value1, const Vector3 value2)
    {
        Vector3 difference = value1 - value2;

        return Vector3::Dot(difference, difference);
    }

    Vector3 Vector3::Divide(const Vector3 left, const Single divisor)
    {
        return left/divisor;
    }

    Vector3 Vector3::Divide(const Vector3 left, const Vector3 right)
    {
        return left/right;
    }

    Single Vector3::Dot(const Vector3 vector1, const Vector3 vector2)
    {
        return vector1.X*vector2.X +
               vector1.Y*vector2.Y +
               vector1.Z*vector2.Z;
    }

    Vector3 Vector3::Lerp(const Vector3 value1, const Vector3 value2, const Single amount)
    {
        Vector3 firstInfluence = value1*(1.0F - amount);
        Vector3 secondInfluence = value2*amount;

        return firstInfluence + secondInfluence;
    }

    Vector3 Vector3::Max(const Vector3 value1, const Vector3 value2)
    {
        return Vector3((value1.X > value2.X) ? value1.X : value2.X,
                       (value1.Y > value2.Y) ? value1.Y : value2.Y,
                       (value1.Z > value2.Z) ? value1.Z : value2.Z);
    }

    Vector3 Vector3::Min(const Vector3 value1, const Vector3 value2)
    {
        return Vector3((value1.X < value2.X) ? value1.X : value2.X,
                       (value1.Y < value2.Y) ? value1.Y : value2.Y,
                       (value1.Z < value2.Z) ? value1.Z : value2.Z);
    }

    Vector3 Vector3::Multiply(const Single left, const Vector3 right)
    {
        return left*right;
    }

    Vector3 Vector3::Multiply(const Vector3 left, const Single right)
    {
        return left*right;
    }

    Vector3 Vector3::Multiply(const Vector3 left, const Vector3 right)
    {
        return left*right;
    }

    Vector3 Vector3::Negate(const Vector3 value)
    {
        return -value;
    }

    Vector3 Vector3::Normalize(const Vector3 value)
    {
        Single length = value.Length();

        return value/length;
    }

    Vector3 Vector3::Reflect(const Vector3 vector, const Vector3 normal)
    {
        Single dot = Dot(vector, normal);
        Vector3 temp = normal*dot*2.0F;

        return vector - temp;
    }

    Vector3 Vector3::SquareRoot(const Vector3 value)
    {
        return Vector3(Single(Math::Sqrt(Double(value.X))), 
                       Single(Math::Sqrt(Double(value.Y))), 
                       Single(Math::Sqrt(Double(value.Z))));
    }


#pragma endregion Public Static Methods

#pragma region Public Instance Methods

    Single Vector3::Length() const
    {
        Single ls = Dot(*this, *this);

        return Single(Math::Sqrt(Double(ls)));
    }

    Single Vector3::LengthSquared() const
    {
        return Dot(*this, *this);
    }

#pragma endregion Public Instance Methods

    Boolean Vector3::Equals(const Vector3& other) const
    {
        return X == other.X && Y == other.Y && Z == other.Z;
    }

    String Vector3::ToString() const
    {
        throw NotImplementedException();
    }

#pragma region Public Operators

    Vector3 Vector3::operator+(const Vector3 other) const
    {
        return Vector3(X + other.X, Y + other.Y, Z + other.Z);
    }

    Vector3 Vector3::operator-(const Vector3 other) const
    {
        return Vector3(X - other.X, Y - other.Y, Z - other.Z);
    }

    Vector3 Vector3::operator-() const
    {
        return GetZero() - *this;
    }

    Vector3 Vector3::operator*(const Single other) const
    {
        return Vector3(X*other, Y*other, Z*other);
    }

    Vector3 Vector3::operator*(const Vector3 other) const
    {
        return Vector3(X*other.X, Y*other.Y, Z*other.Z);
    }

    Vector3 Vector3::operator/(const Single other) const
    {
        Single invDiv = 1.0F/other;

        return Vector3(X*invDiv, Y*invDiv, Z*invDiv);
    }

    Vector3 Vector3::operator/(const Vector3 other) const
    {
        return Vector3(X/other.X, Y/other.Y, Z/other.Z);
    }

    Boolean Vector3::operator==(const Vector3 other) const
    {
        return this->Equals(other);
    }

#pragma endregion Public Operators
}

System::Numerics::Vector3 operator*(System::Single lhs, System::Numerics::Vector3 rhs)
{
    return System::Numerics::Vector3(lhs) * rhs;
}
