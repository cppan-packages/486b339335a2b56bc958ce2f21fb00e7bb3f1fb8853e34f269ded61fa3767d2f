/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Quaternion.hpp"

#include "Vector3.hpp"
#include "../Boolean.hpp"
#include "../Math.hpp"
#include "../Double.hpp"

namespace System::Numerics
{
#pragma region Public Constructors

    Quaternion::Quaternion()
    {
        Quaternion(0.0F, 0.0F, 0.0F, 1.0F);
    }

    Quaternion::Quaternion(const Single x, const Single y, const Single z, const Single w)
    {
        this->X = x;
        this->Y = y;
        this->Z = z;
        this->W = w;
    }

    Quaternion::Quaternion(const Vector3 vectorPart, const Single scalarPart)
    {
        Quaternion(vectorPart.X, vectorPart.Y, vectorPart.Z, scalarPart);
    }

#pragma endregion Public Constructors

#pragma region Public Static Properties

    Quaternion Quaternion::GetIdentity()
    {
        return Quaternion(0.0F, 0.0F, 0.0F, 1.0F);
    }

#pragma endregion Public Static Properties

#pragma region Public Instance Properties

    Boolean Quaternion::GetIsIdentity() const
    {
        return X == 0.0F && Y == 0.0F && Z == 0.0F && W == 1.0F;
    }

#pragma endregion Public Instance Properties

#pragma region Public Static Methods

    Quaternion Quaternion::Add(const Quaternion value1, const Quaternion value2)
    {
        return value1 + value2;
    }

    Quaternion Quaternion::Concatenate(const Quaternion value1, const Quaternion value2)
    {
        Quaternion ans;

        // Concatenate rotation is actually q2 * q1 instead of q1 * q2.
        // So that's why value2 goes q1 and value1 goes q2.
        Single q1x = value2.X;
        Single q1y = value2.Y;
        Single q1z = value2.Z;
        Single q1w = value2.W;

        Single q2x = value1.X;
        Single q2y = value1.Y;
        Single q2z = value1.Z;
        Single q2w = value1.W;

        // cross(av, bv)
        Single cx = q1y * q2z - q1z * q2y;
        Single cy = q1z * q2x - q1x * q2z;
        Single cz = q1x * q2y - q1y * q2x;

        Single dot = q1x * q2x + q1y * q2y + q1z * q2z;

        ans.X = q1x * q2w + q2x * q1w + cx;
        ans.Y = q1y * q2w + q2y * q1w + cy;
        ans.Z = q1z * q2w + q2z * q1w + cz;
        ans.W = q1w * q2w - dot;

        return ans;
    }

    Quaternion Quaternion::Conjugate(const Quaternion value)
    {
        Quaternion result;

        result.X = -value.X;
        result.Y = -value.Y;
        result.Z = -value.Z;
        result.W = value.W;

        return result;
    }

    Quaternion Quaternion::CreateFromAxisAngle(const Vector3 axis, const Single angle)
    {
        Quaternion result;

        Single halfAngle = angle * 0.5f;
        Single s = Single(Math::Sin(Double(halfAngle)));
        Single c = Single(Math::Cos(Double(halfAngle)));

        result.X = axis.X * s;
        result.Y = axis.Y * s;
        result.Z = axis.Z * s;
        result.W = c;

        return result;
    }

    Quaternion Quaternion::CreateFromYawPitchRoll(const Single yaw, const Single pitch, const Single roll)
    {
        // Roll first, about axis the object is facing, then pitch upward, then yaw to face into the new heading.

        Single sr;
        Single cr;
        Single sp;
        Single cp;
        Single sy;
        Single cy;

        Single halfRoll = roll * 0.5f;
        sr = Single(Math::Sin(Double(halfRoll)));
        cr = Single(Math::Cos(Double(halfRoll)));

        Single halfPitch = pitch * 0.5f;
        sp = Single(Math::Sin(Double(halfPitch)));
        cp = Single(Math::Cos(Double(halfPitch)));

        Single halfYaw = yaw * 0.5f;
        sy = Single(Math::Sin(Double(halfYaw)));
        cy = Single(Math::Cos(Double(halfYaw)));

        Quaternion result;

        result.X = cy * sp * cr + sy * cp * sr;
        result.Y = sy * cp * cr - cy * sp * sr;
        result.Z = cy * cp * sr - sy * sp * cr;
        result.W = cy * cp * cr + sy * sp * sr;

        return result;
    }

    Quaternion Quaternion::Divide(const Quaternion value1, const Quaternion value2)
    {
        Quaternion result;

        Single q1x = value1.X;
        Single q1y = value1.Y;
        Single q1z = value1.Z;
        Single q1w = value1.W;

        //-------------------------------------
        // Inverse part.
        Single ls = value2.X * value2.X + value2.Y * value2.Y + value2.Z * value2.Z + value2.W * value2.W;
        Single invNorm = 1.0f / ls;

        Single q2x = -value2.X * invNorm;
        Single q2y = -value2.Y * invNorm;
        Single q2z = -value2.Z * invNorm;
        Single q2w = value2.W * invNorm;

        //-------------------------------------
        // Multiply part.

        // cross(av, bv)
        Single cx = q1y * q2z - q1z * q2y;
        Single cy = q1z * q2x - q1x * q2z;
        Single cz = q1x * q2y - q1y * q2x;

        Single dot = q1x * q2x + q1y * q2y + q1z * q2z;

        result.X = q1x * q2w + q2x * q1w + cx;
        result.Y = q1y * q2w + q2y * q1w + cy;
        result.Z = q1z * q2w + q2z * q1w + cz;
        result.W = q1w * q2w - dot;

        return result;
    }

    Single Quaternion::Dot(const Quaternion quaternion1, const Quaternion quaternion2)
    {
        return quaternion1.X * quaternion2.X +
            quaternion1.Y * quaternion2.Y +
            quaternion1.Z * quaternion2.Z +
            quaternion1.W * quaternion2.W;
    }

#pragma endregion Public Static Methods

#pragma region Public Instance Methods

    Single Quaternion::Length() const
    {
        Single ls = X * X + Y * Y + Z * Z + W * W;

        return Single(Math::Sqrt(Double(ls)));
    }

    Single Quaternion::LengthSquared() const
    {
        return X * X + Y * Y + Z * Z + W * W;
    }

#pragma endregion Public Instance Methods

#pragma region Public Operators

    Quaternion Quaternion::operator-() const
    {
        Quaternion result;

        result.X = -X;
        result.Y = -Y;
        result.Z = -Z;
        result.W = -W;

        return result;
    }

    Quaternion Quaternion::operator+(const Quaternion right) const
    {
        Quaternion result;

        result.X = X + right.X;
        result.Y = Y + right.Y;
        result.Z = Z + right.Z;
        result.W = W + right.W;

        return result;
    }

#pragma endregion Public Operators
}
