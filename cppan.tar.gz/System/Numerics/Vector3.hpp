/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../IEquatable.hpp"
#include "../Single.hpp"
#include "../ValueType.hpp"

namespace System::Numerics
{
    struct Vector2;
}

namespace System::Numerics
{
    /**
     * \brief Represents a vector with three single-precision floating-point values.
     * \remarks The Vector3 structure provides support for hardware acceleration.
     */
    struct Vector3 final : public ValueType, public IEquatable<Vector3>/*, IFormattable*/
    {

    public:

#pragma region Public Instance Variables

        /**
         * \brief The X component of the vector.
         */
        Single X;

        /**
        * \brief The Y component of the vector.
        */
        Single Y;
        
        /**
        * \brief The Z component of the vector.
        */
        Single Z;

#pragma endregion Public Instance Variables

#pragma region Public Constructors

        /**
         * \brief Creates a new Vector3 object whose three elements have the same value.
         * \param value The value to assign to all three elements.
         */
        explicit Vector3(const Single value);

        /**
         * \brief Creates a vector whose elements have the specified values.
         * \param x The value to assign to the X field.
         * \param y The value to assign to the Y field.
         * \param z The value to assign to the Z field.
         */
        explicit Vector3(const Single x, const Single y, const Single z);

        /**
         * \brief Creates a new Vector3 object from the specified Vector2 object and the specified value.
         * \param value The vector with two elements.
         * \param z The additional value to assign to the Z field.
         */
        explicit Vector3(Vector2 value, float z);

#pragma endregion Public Constructors

#pragma region Public Destructor

        ~Vector3();

#pragma endregion Public Destructor

#pragma region Public Static Properties

        /**
         * \brief 
         * \return 
         */
        static Vector3 GetZero();

        /**
         * \brief Gets a vector whose 3 elements are equal to one.
         * \return A vector whose three elements are equal to one (that is, it returns the vector (1,1,1).
         */
        static Vector3 GetOne();

        /**
         * \brief 
         * \return 
         */
        static Vector3 GetUnitX();

        /**
         * \brief 
         * \return 
         */
        static Vector3 GetUnitY();
        
        /**
         * \brief 
         * \return 
         */
        static Vector3 GetUnitZ();

#pragma endregion Public Static Properties

#pragma region Public Static Methods

        /**
         * \brief Returns a vector whose elements are the absolute values of each of the specified vector's elements.
         * \param value A vector.
         * \return The absolute value vector.
         */
        static Vector3 Abs(const Vector3 value);

        /**
         * \brief Adds two vectors together.
         * \param left The first vector to add.
         * \param right The second vector to add.
         * \return The summed vector.
         */
        static Vector3 Add(const Vector3 left, const Vector3 right);

        /**
         * \brief Restricts a vector between a minimum and a maximum value.
         * \param value1 The vector to restrict.
         * \param min The minimum value.
         * \param max The maximum value.
         * \return The restricted vector.
         */
        static Vector3 Clamp(const Vector3 value1, const Vector3 min, const Vector3 max);

        /**
         * \brief Computes the cross product of two vectors.
         * \param vector1 The first vector.
         * \param vector2 The second vector.
         * \return The cross product.
         */
        static Vector3 Cross(const Vector3 vector1, const Vector3 vector2);

        /**
         * \brief Computes the Euclidean distance between the two given points.
         * \param value1 The first point.
         * \param value2 The second point.
         * \return The distance.
         */
        static Single Distance(const Vector3 value1, const Vector3 value2);

        /**
         * \brief 
         * \param value1 
         * \param value2 
         * \return 
         */
        static Single DistanceSquared(const Vector3 value1, const Vector3 value2);

        /**
         * \brief 
         * \param left 
         * \param divisor 
         * \return 
         */
        static Vector3 Divide(const Vector3 left, const Single divisor);

        /**
         * \brief 
         * \param left 
         * \param right 
         * \return 
         */
        static Vector3 Divide(const Vector3 left, const Vector3 right);

        /**
         * \brief 
         * \param vector1 
         * \param vector2 
         * \return 
         */
        static Single Dot(const Vector3 vector1, const Vector3 vector2);

        /**
         * \brief Performs a linear interpolation between two vectors based on the given weighting.
         * \param value1 The first vector.
         * \param value2 The second vector.
         * \param amount A value between 0 and 1 that indicates the weight of value2.
         * \return The interpolated vector.
         */
        static Vector3 Lerp(const Vector3 value1, const Vector3 value2, const Single amount);

         /**
         * \brief Returns a vector whose elements are the maximum of each of the pairs of elements in two specified vectors.
         * \param value1 The first vector.
         * \param value2 The second vector.
         * \return The maximized vector.
         */
        static Vector3 Max(const Vector3 value1, const Vector3 value2);

        /**
        * \brief Returns a vector whose elements are the minimum of each of the pairs of elements in two specified vectors.
        * \param value1 The first vector.
        * \param value2 The second vector.
        * \return The minimized vector.
        */
        static Vector3 Min(const Vector3 value1, const Vector3 value2);

        /**
         * \brief Multiplies a scalar value by a specified vector.
         * \param left The scaled value.
         * \param right The vector.
         * \return The scaled vector.
         */
        static Vector3 Multiply(const Single left, const Vector3 right);
        
        /**
         * \brief Multiplies a vector by a specified scalar.
         * \param left The vector to multiply.
         * \param right The scalar value.
         * \return The scaled vector.
         */
        static Vector3 Multiply(const Vector3 left, const Single right);
        
        /**
         * \brief Multiplies two vectors together.
         * \param left The first vector.
         * \param right The second vector.
         * \return The product vector.
         */
        static Vector3 Multiply(const Vector3 left, const Vector3 right);
        
        /**
         * \brief Negates a specified vector.
         * \param value The vector to negate.
         * \return The negated vector.
         */
        static Vector3 Negate(const Vector3 value);
        
        /**
         * \brief Returns a vector with the same direction as the specified vector, but with a length of one.
         * \param value The vector to normalize.
         * \return The normalized vector.
         */
        static Vector3 Normalize(const Vector3 value);

        /**
         * \brief Returns the reflection of a vector off a surface that has the specified normal.
         * \param vector The source vector.
         * \param normal The normal of the surface being reflected off.
         * \return The reflected vector.
         */
        static Vector3 Reflect(const Vector3 vector, const Vector3 normal);

        /**
         * \brief Returns a vector whose elements are the square root of each of a specified vector's elements.
         * \param value A vector.
         * \return The square root vector.
         */
        static Vector3 SquareRoot(const Vector3 value);

#pragma endregion Public Static Methods

#pragma region Public Instance Methods

        /**
         * \brief Returns the length of this vector object.
         * \return The vector's length.
         */
        Single Length() const;

        /**
         * \brief Returns the length of the vector squared.
         * \return The vector's length squared.
         */
        Single LengthSquared() const;

#pragma endregion Public Instance Methods

        Boolean Equals(const Vector3& other) const override;

        String ToString() const override;

#pragma region Public Operators

        Vector3 operator+(const Vector3 other) const;

        Vector3 operator-(const Vector3 other) const;

        /**
         * \brief Negates the specified vector.
         * \return The negated vector.
         * \remarks The UnaryNegation method defines the unary negation operation for Vector3 objects.
         */
        Vector3 operator-() const;

        Vector3 operator*(const Single other) const;

        Vector3 operator*(const Vector3 other) const;

        Vector3 operator/(const Single other) const;

        Vector3 operator/(const Vector3 other) const;

        Boolean operator==(const Vector3 other) const;

#pragma endregion Public Operators

    };
}
    
/**
 * \brief 
 * \param lhs 
 * \param rhs 
 * \return 
 */
inline System::Numerics::Vector3 operator*(System::Single lhs, System::Numerics::Vector3 rhs);
