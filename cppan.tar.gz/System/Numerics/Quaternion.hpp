/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../ValueType.hpp"
#include "../Single.hpp"

#pragma region Forward Declarations

namespace System::Numerics
{
    struct Vector3;
    struct Matrix4x4;
}

#pragma endregion Forward Declarations

namespace System::Numerics
{
    struct Quaternion final : public ValueType
    {
    public:

#pragma region Public Instance Variables

        /**
         * \brief The X value of the vector component of the quaternion.
         */
        Single X;

        /**
        * \brief The Y value of the vector component of the quaternion.
        */
        Single Y;

        /**
        * \brief The Z value of the vector component of the quaternion.
        */
        Single Z;

        /**
        * \brief The rotation component of the quaternion.
        */
        Single W;

#pragma endregion Public Instance Variables

#pragma region Public Constructors

        Quaternion();

        /**
         * \brief Constructs a quaternion from the specified components.
         * \param x The value to assign to the X component of the quaternion.
         * \param y The value to assign to the Y component of the quaternion.
         * \param z The value to assign to the Z component of the quaternion.
         * \param w The value to assign to the W component of the quaternion.
         */
        Quaternion(const Single x, const Single y, const Single z, const Single w);

        /**
         * \brief Creates a quaternion from the specified vector and rotation parts.
         * \param vectorPart The vector part of the quaternion.
         * \param scalarPart The rotation part of the quaternion.
         */
        Quaternion(const Vector3 vectorPart, const Single scalarPart);

#pragma endregion Public Constructors

#pragma region Public Static Properties

        /**
         * \brief Gets a quaternion that represents no rotation.
         * \return A quaternion whose values are (0, 0, 0, 1). 
         */
        static Quaternion GetIdentity();

#pragma endregion Public Static Properties

#pragma region Public Instance Properties

        /**
         * \brief Gets a value that indicates whether the current instance is the identity quaternion.
         * \return true if the current instance is the identity quaternion; otherwise, false. 
         */
        Boolean GetIsIdentity() const;

#pragma endregion Public Instance Properties

#pragma region Public Static Methods

        /**
         * \brief Adds each element in one quaternion with its corresponding element in a second quaternion.
         * \param value1 The first quaternion.
         * \param value2 The second quaternion.
         * \return The quaternion that contains the summed values of value1 and value2. 
         */
        static Quaternion Add(const Quaternion value1, const Quaternion value2);

        /**
         * \brief Concatenates two quaternions.
         * \param value1 The first quaternion rotation in the series.
         * \param value2 The second quaternion rotation in the series.
         * \return A new quaternion representing the concatenation of the value1 rotation followed by the value2 rotation. 
         */
        static Quaternion Concatenate(const Quaternion value1, const Quaternion value2);

        /**
         * \brief Returns the conjugate of a specified quaternion.
         * \param value The quaternion.
         * \return A new quaternion that is the conjugate of value. 
         */
        static Quaternion Conjugate(const Quaternion value);

        /**
         * \brief Creates a quaternion from a vector and an angle to rotate about the vector.
         * \param axis The vector to rotate around.
         * \param angle The angle, in radians, to rotate around the vector.
         * \return The newly created quaternion.
         */
        static Quaternion CreateFromAxisAngle(const Vector3 axis, const Single angle);

        /**
         * \brief 
         * \param matrix 
         * \return 
         */
        static Quaternion CreateFromRotationMatrix(const Matrix4x4 matrix);

        /**
         * \brief Creates a new quaternion from the given yaw, pitch, and roll.
         * \param yaw The yaw angle, in radians, around the Y axis.
         * \param pitch The pitch angle, in radians, around the X axis.
         * \param roll The roll angle, in radians, around the Z axis.
         * \return The resulting quaternion. 
         */
        static Quaternion CreateFromYawPitchRoll(const Single yaw, const Single pitch, const Single roll);

        /**
         * \brief Divides one quaternion by a second quaternion.
         * \param value1 The dividend.
         * \param value2 The divisor.
         * \return The quaternion that results from dividing value1 by value2. 
         */
        static Quaternion Divide(const Quaternion value1, const Quaternion value2);

        /**
         * \brief Calculates the dot product of two quaternions.
         * \param quaternion1 The first quaternion.
         * \param quaternion2 The second quaternion.
         * \return The dot product. 
         */
        static Single Dot(const Quaternion quaternion1, const Quaternion quaternion2);

#pragma endregion Public Static Methods

#pragma region Public Instance Methods

        /**
         * \brief Calculates the length of the quaternion.
         * \return The computed length of the quaternion. 
         */
        Single Length() const;

        /**
         * \brief Calculates the squared length of the quaternion.
         * \return The length squared of the quaternion. 
         */
        Single LengthSquared() const;

#pragma endregion 
        
#pragma region Public Operators

        /**
         * \brief Reverses the sign of each component of the quaternion.
         * \return The negated quaternion. 
         */
        Quaternion operator-() const;

        /**
         * \brief Subtracts each element in a second quaternion from its corresponding element in a first quaternion.
         * \param right The second quaternion.
         * \return The quaternion containing the values that result from subtracting each element in value2 from its corresponding 
         *         element in value1. 
         */
        Quaternion operator+(const Quaternion right) const;

#pragma endregion Public Operators

    };
}
