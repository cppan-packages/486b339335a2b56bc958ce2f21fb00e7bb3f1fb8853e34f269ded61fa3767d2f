/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"

#include <string>

#pragma region Forward Declarations

namespace System
{
    struct Char;

    class IndexOutOfRangeException;
}

#pragma endregion

namespace System
{
    /**
     * \brief Represents text as a sequence of UTF-16 code units.
     */
    class DLLExport String final : public Object
    {
    public:

        /**
         * \brief Represents the empty string. This field is read-only.
         */
        static const String Empty;

#pragma region Public Constructos

        String();

        String(const char value);

        /**
         * \brief Initializes a new instance of the String class to the value indicated by an array of Unicode characters.
         * \param value An array of Unicode characters.
         */
        String(const char value[]);

        String(const std::string value);

        String(const Object value);

#pragma endregion

#pragma region Public Destructor

        ~String();

#pragma endregion

#pragma region Public Instance Properties

        /**
         * \brief Gets the number of characters in the current String object.
         * \return The number of characters in the current string.
         */
        Int32 GetLength() const;

#pragma endregion

#pragma region Public Static Methods

        /**
         * \brief Indicates whether the specified string is null or an Empty string.
         * \param value true if the value parameter is null or an empty string (""); otherwise, false.
         * \return The string to test.
         */
        static Boolean IsNullOrEmpty(const String& value);

        /**
         * \brief Indicates whether a specified string is null, empty, or consists only of white-space characters.
         * \param value The string to test.
         * \return true if the value parameter is null or String::Empty, or if value consists exclusively of white-space characters.
         */
        static Boolean IsNullOrWhiteSpace(const String& value);

#pragma endregion

#pragma region Public Instance Methods

#pragma endregion

#pragma region  Public Overrided Methods

        String ToString() const override;

#pragma endregion

#pragma region Public Operators

        String operator+(const String& value) const;
        String operator+(const Object& value) const;

        Boolean operator==(const String& value) const;

        /**
        * \brief Gets the Char object at a specified position in the current String object.
        * \param index A position in the current string.
        * \return The object at position index.
        * \exception IndexOutOfRangeException index is greater than or equal to the length of this object or less than zero.
        */
        Char operator[](const Int32& index) const;

#pragma endregion

        operator std::string() const;
        explicit operator char*() const;

    private:
        std::string* value;
    };

#pragma region Global Operator Overloads

    inline String operator+(const char lhs[], const String& rhs)
    {
        return String(lhs) + rhs;
    }

    inline String operator+(const char lhs[], const Object& rhs)
    {
        return String(lhs) + rhs.ToString();
    }

#pragma endregion
}
