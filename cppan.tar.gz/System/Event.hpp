/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Delegate.hpp"
#include "Collections/Generic/List.hpp"

namespace Helper
{
    template <int... Is>
    struct Index
    {
    };

    template <int N, int... Is>
    struct SequenceGenerator : SequenceGenerator<N - 1, N - 1, Is...>
    {
    };

    template <int... Is>
    struct SequenceGenerator<0, Is...> : Index<Is...>
    {
    };
}

namespace System
{
    /**
     * \brief 
     * \tparam TDelegate The type of the event's delegate.
     */
    template <class TDelegate>
    class Event final
    {
    public:

#pragma Type Definitions

        using Result = typename TDelegate::Result;
        using Args = typename TDelegate::Args;

        template <typename ... TArgs>
        using DelegateType = Delegate<Result, TArgs...>;

#pragma endregion

#pragma region Public Constructors

        explicit Event();

#pragma endregion

#pragma region Public Operators

        void operator+=(TDelegate& rhs);

        void operator-=(TDelegate& rhs);

        template <typename ... TArgs>
        void operator()(TArgs ... args);

#pragma endregion

    private:

#pragma region Private Variables

        Collections::Generic::List<TDelegate> listeners;

#pragma endregion

#pragma region Private Instance Methods

        void Subscribe(TDelegate& delegate);

        void Unsubscribe(TDelegate& delegate);

#pragma endregion
    };

#pragma region Public Constructors

    template <typename TDelegate>
    Event<TDelegate>::Event()
    {
    }

#pragma endregion

#pragma region Public Operators

    template <typename TDelegate>
    void Event<TDelegate>::operator+=(TDelegate& rhs)
    {
        Subscribe(rhs);
    }

    template <typename TDelegate>
    void Event<TDelegate>::operator-=(TDelegate& rhs)
    {
        Unsubscribe(rhs);
    }

    template <typename TDelegate>
    template <typename ... TArgs>
    void Event<TDelegate>::operator()(TArgs ... args)
    {
        int count = listeners.GetCount();
        for (Int32 i = 0; i < count; ++i)
        {
            listeners[i](args...);
        }
    }

#pragma endregion

#pragma region Private Instance Methods

    template <typename TDelegate>
    void Event<TDelegate>::Subscribe(TDelegate& delegate)
    {
        if (!listeners.Contains(delegate))
        {
            listeners.Add(delegate);
        }
    }

    template <typename TDelegate>
    void Event<TDelegate>::Unsubscribe(TDelegate& delegate)
    {
        listeners.Remove(delegate);
    }

#pragma endregion


    template <typename TResult, typename ... TArgs>
    inline bool operator==(const Delegate<TResult, TArgs...>& lhs, const Delegate<TResult, TArgs...>& rhs)
    {
        return true;
    }
}
