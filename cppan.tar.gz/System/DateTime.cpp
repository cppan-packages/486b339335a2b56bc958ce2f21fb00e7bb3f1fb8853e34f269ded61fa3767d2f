/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "DateTime.hpp"

#include "Boolean.hpp"
#include "Int32.hpp"
#include "Int64.hpp"
#include "Double.hpp"
#include "DateTimeKind.hpp"
#include "Exception.hpp"

#include <chrono>

namespace System
{
#pragma region Private Static Constants

    const Int32 DateTime::MinMillisecond = 0;
    const Int32 DateTime::MaxMilisecond = 999;
    const Int32 DateTime::MinSecond = 0;
    const Int32 DateTime::MaxSecond = 59;
    const Int32 DateTime::MinMinute = 0;
    const Int32 DateTime::MaxMinute = 59;
    const Int32 DateTime::MinHour = 0;
    const Int32 DateTime::MaxHour = 23;
    const Int32 DateTime::MinDay = 1;
    const Int32 DateTime::MaxDay = 31;
    const Int32 DateTime::MinMonth = 1;
    const Int32 DateTime::MaxMonth = 12;
    const Int32 DateTime::MinYear = 1;
    const Int32 DateTime::MaxYear = 9999;

    const Int32 DateTime::SecondsPerMinute = 60;
    const Int32 DateTime::MinutesPerHour = 60;
    const Int32 DateTime::HoursPerDay = 24;

    const Int64 DateTime::TicksPerMillisecond = 10000;
    const Int64 DateTime::TicksPerSecond = TicksPerMillisecond * 1000;
    const Int64 DateTime::TicksPerMinute = TicksPerSecond * SecondsPerMinute;
    const Int64 DateTime::TicksPerHour = TicksPerMinute * MinutesPerHour;
    const Int64 DateTime::TicksPerDay = TicksPerHour * HoursPerDay;

    const Int32 DateTime::MillisecondsPerSecond = 1000;
    const Int32 DateTime::MillisecondsPerMinute = MillisecondsPerSecond * SecondsPerMinute;
    const Int32 DateTime::MillisecondsPerHour = MillisecondsPerMinute * MinutesPerHour;
    const Int32 DateTime::MillisecondsPerDay = MillisecondsPerHour * HoursPerDay;

    const Int32 DateTime::DaysPerWeek = 7;
    const Int32 DateTime::DaysPerYear = 365;
    const Int32 DateTime::DaysPerLeapYear = 365 + 1;
    const Int32 DateTime::DaysPer4Years = DaysPerYear * 4 + 1;
    const Int32 DateTime::DaysPer100Years = DaysPer4Years * 25 - 1;
    const Int32 DateTime::DaysPer400Years = DaysPer100Years * 4 + 1;

    const Int32 DateTime::DaysTo1601 = DaysPer400Years * 4;
    const Int32 DateTime::DaysTo1899 = DaysPer400Years * 4 + DaysPer100Years * 3 - 367;
    const Int32 DateTime::DaysTo1970 = DaysPer400Years * 4 + DaysPer100Years * 3 + DaysPer4Years * 17 + DaysPerYear;
    const Int32 DateTime::DaysTo10000 = DaysPer400Years * 25 - 366;

    const Int64 DateTime::MinTicks = 0;
    const Int64 DateTime::MaxTicks = (DaysTo10000 * TicksPerDay) - 1;
    const Int64 DateTime::MaxMillisecond = Int64(DaysTo10000) * MillisecondsPerDay;

    const Int64 DateTime::FileTimeOffset = DaysTo1601 * TicksPerDay;
    const Int64 DateTime::DoubleDateOffset = DaysTo1899 * TicksPerDay;
    const Int64 DateTime::OADateMinAsTicks = (DaysPer100Years - DaysPerYear) * TicksPerDay;
    const Double DateTime::OADateMinAsDouble = -657435.0;
    const Double DateTime::OADateMaxAsDouble = 2958466.0;

    const Array<Int32, 13> DateTime::DaysToMonth365 = {{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365}};
    const Array<Int32, 13> DateTime::DaysToMonth366 = {{0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366}};

    const UInt64 DateTime::TicksMask = 0x3FFFFFFFFFFFFFFF;
    const UInt64 DateTime::FlagsMask = 0xC000000000000000;
    const UInt64 DateTime::LocalMask = 0x8000000000000000;
    const Int64 DateTime::TicksCeiling = 0x4000000000000000;
    const UInt64 DateTime::KindUnspecified = 0x0000000000000000;
    const UInt64 DateTime::KindUtc = 0x4000000000000000;
    const UInt64 DateTime::KindLocal = 0x8000000000000000;
    const UInt64 DateTime::KindLocalAmbiguousDst = 0xC000000000000000;
    const Int32 DateTime::KindShift = 62;

    const DateTime DateTime::UnixEpoch = DateTime(1970, 1, 1);

#pragma endregion

#pragma region Public Constants

    const DateTime DateTime::MaxValue = DateTime(MaxTicks);
    const DateTime DateTime::MinValue = DateTime(MinTicks);

#pragma endregion

#pragma region Private Constructors

    DateTime::DateTime(const UInt64& dateData)
    {
        this->dateData = dateData;
    }

    DateTime::DateTime(const Int64& ticks, const DateTimeKind& kind, const Boolean& isAmbiguousDST)
    {
        if (ticks < MinTicks || ticks > MaxTicks)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        //Contract.Requires(kind == DateTimeKind.Local, "Internal Constructor is for local times only");

        dateData = (UInt64(ticks) | (isAmbiguousDST ? KindLocalAmbiguousDst : KindLocal));
    }

#pragma endregion

#pragma region Public Constructors

    DateTime::DateTime()
    {
        this->dateData = MinTicks;
    }

    DateTime::DateTime(const Int64& ticks)
    {
        // Throws an exception if the specified ticks is smaller of larger than the min or max amount. 
        if (ticks < MinTicks || ticks > MaxTicks)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        this->dateData = UInt64(ticks);
    }

    DateTime::DateTime(const Int64& ticks, const DateTimeKind& kind)
    {
        // Throws an exception if the specified ticks is smaller of larger than the min or max amount. 
        if (ticks < MinTicks || ticks > MaxTicks)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        if (kind < DateTimeKind::Unspecified || kind > DateTimeKind::Local)
        {
            throw Exception("ArgumentException");
        }

        this->dateData = (UInt64(ticks) | (UInt64(kind) << KindShift));
    }

    DateTime::DateTime(const Int32& year, const Int32& month, const Int32& day)
    {
        this->dateData = UInt64(DateToTicks(year, month, day));
    }

    DateTime::DateTime(const Int32& year, const Int32& month, const Int32& day, const Int32& hour, const Int32& minute,
                       const Int32& second)
    {
        this->dateData = UInt64(DateToTicks(year, month, day) + TimeToTicks(hour, minute, second));
    }

    DateTime::DateTime(const Int32& year, const Int32& month, const Int32& day, const Int32& hour, const Int32& minute,
                       const Int32& second, const Int32& millisecond)
    {
        // Throws an exception if the specified millisecond is smaller of larger than the min or max amount. 
        if (millisecond < MinMillisecond || millisecond > MaxMillisecond)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        Int64 ticks = DateToTicks(year, month, day) + TimeToTicks(hour, minute, second);
        ticks += millisecond * TicksPerMillisecond;

        // Throws an exception if the specified ticks is smaller of larger than the min or max amount. 
        if (ticks < MinTicks || ticks > MaxTicks)
        {
            throw Exception("ArgumentException");
        }

        this->dateData = UInt64(ticks);
    }

#pragma endregion

#pragma region Private Static Methods

    Int64 DateTime::DateToTicks(const Int32& year, const Int32& month, const Int32& day)
    {
        if (year >= MinYear && year <= MaxYear && month >= MinMonth && month <= MaxMonth)
        {
            Array<Int32, 13> days = IsLeapYear(year) ? DaysToMonth366 : DaysToMonth365;
            if (day >= 1 && day <= days[month] - days[month - 1])
            {
                Int32 y = year - 1;
                Int32 n = y * 365 + y / 4 - y / 100 + y / 400 + days[month - 1] + day - 1;
                return n * TicksPerDay;
            }
        }
        throw Exception("ArgumentOutOfRangeException");
    }

    Int64 DateTime::TimeToTicks(const Int32& hour, const Int32& minute, const Int32& second)
    {
        //TimeSpan.TimeToTicks is a family access function which does no error checking, so
        //we need to put some error checking out here.
        if (hour >= 0 && hour < 24 && minute >= 0 && minute < 60 && second >= 0 && second < 60)
        {
            return 0;//TimeSpan::TimeToTicks(hour, minute, second);
        }
        throw Exception("ArgumentOutOfRangeException");
    }

    Boolean DateTime::IsLeapYear(const Int32& year)
    {
        if (year < 1 || year > 9999)
        {
            throw Exception("ArgumentOutOfRange_Year");
        }

        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }

    Int32 DateTime::DaysInMonth(const Int32& year, const Int32& month)
    {
        if (month < MinMonth || month > MaxMonth)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        // IsLeapYear checks the year argument
        Array<Int32, 13> days = IsLeapYear(year) ? DaysToMonth366 : DaysToMonth365;

        return days[month] - days[month - 1];
    }

#pragma endregion

#pragma region Public Static Properties

    //DateTime DateTime::GetNow()
    //{
    //    DateTime utc = GetUtcNow();
    //    Boolean isAmbiguousLocalDst = false;

    //    Int64 offset = TimeZoneInfo.GetDateTimeNowUtcOffsetFromUtc(utc, out isAmbiguousLocalDst).Ticks;

    //    Int64 tick = utc.GetTicks() + offset;

    //    if (tick > DateTime::MaxTicks)
    //    {
    //        return DateTime(MaxTicks, DateTimeKind::Local);
    //    }

    //    if (tick < DateTime::MinTicks)
    //    {
    //        return DateTime(MinTicks, DateTimeKind::Local);
    //    }

    //    return DateTime(tick, DateTimeKind::Local, isAmbiguousLocalDst);
    //}

    DateTime DateTime::GetUtcNow()
    {
        Int64 ticks = GetSystemTime();
        return DateTime(UInt64(ticks + UnixEpoch.GetTicks()) | KindUtc);
    }

    Int64 DateTime::GetSystemTime()
    {
        //using ticks = std::chrono::duration<std::int64_t, std::ratio_multiply<std::ratio<100>, std::nano>>;
        //std::chrono::system_clock::time_point(ticks(GetInternalTicks() - 22089888000000000));

        auto now = std::chrono::system_clock::now();
        auto epoch = now.time_since_epoch();

        return epoch.count();
    }

#pragma endregion

#pragma region Public Instance Properties

    DateTime::Type_Day DateTime::get_Day() const
    {
        return GetDatePart(DatePart::Day);
    }

    DayOfWeek DateTime::GetDayOfWeek() const
    {
        return DayOfWeek((GetInternalTicks() / TicksPerDay + 1) % DaysPerWeek);
    }

    DateTime::Type_DayOfYear DateTime::get_DayOfYear() const
    {
        return GetDatePart(DatePart::DayOfYear);
    }

    DateTime::Type_Hour DateTime::get_Hour() const
    {
        return Int32((GetInternalTicks() / TicksPerHour) % HoursPerDay);
    }

    Int32 DateTime::GetMillisecond() const
    {
        return Int32((GetInternalTicks() / TicksPerMillisecond) % MillisecondsPerSecond);
    }

    Int32 DateTime::GetMinute() const
    {
        return Int32((GetInternalTicks() / TicksPerMinute) % MinutesPerHour);
    }

    Int32 DateTime::GetMonth() const
    {
        return GetDatePart(DatePart::Month);
    }

    Int32 DateTime::GetSecond() const
    {
        return Int32((GetInternalTicks() / TicksPerSecond) % SecondsPerMinute);
    }

    Int32 DateTime::GetYear() const
    {
        return GetDatePart(DatePart::Year);
    }

    Int64 DateTime::GetTicks() const
    {
        return GetInternalTicks();
    }

#pragma endregion

#pragma region Public Instance Methods

    DateTime DateTime::AddTicks(const Int64& value) const
    {
        Int64 ticks = GetInternalTicks();

        if (value > MaxTicks - ticks || value < MinTicks - ticks)
        {
            throw Exception("ArgumentOutOfRangeException");
        }

        return DateTime(UInt64(ticks + value) | GetInternalKind());
    }

#pragma endregion

#pragma region Public Overriden Instance Methods

    String DateTime::ToString() const
    {
        return Day.ToString() + "/" + GetMonth().ToString() + "/" + GetYear().ToString() + " " +
            Hour.ToString() + ":" + GetMinute().ToString() + ":" + GetSecond().ToString() + ":" + GetMillisecond().ToString();
    }

#pragma endregion

#pragma region Private Instance Methods

    Int64 DateTime::GetInternalTicks() const
    {
        return Int64(dateData & TicksMask);
    }

    UInt64 DateTime::GetInternalKind() const
    {
        return dateData & FlagsMask;
    }

    Int32 DateTime::GetDatePart(const DatePart& datePart) const
    {
        Int64 ticks = GetInternalTicks();

        // The number of days since 01/01/0001.
        Int32 n = Int32(ticks / TicksPerDay);

        // The number of whole 400-year periods since 01/01/0001.
        Int32 y400 = n / DaysPer400Years;

        // The day number within 400-year period
        n -= y400 * DaysPer400Years;

        // The number of whole 100-year periods within 400-year period.
        Int32 y100 = n / DaysPer100Years;

        // Last 100-year period has an extra day, so decrement result if 4
        if (y100 == 4)
        {
            y100 = 3;
        }

        // The day number within 100-year period
        n -= y100 * DaysPer100Years;

        // The number of whole 4-year periods within 100-year period.
        Int32 y4 = n / DaysPer4Years;

        // The day number within 4-year period.
        n -= y4 * DaysPer4Years;

        // y1 = number of whole years within 4-year period
        int y1 = n / DaysPerYear;
        // Last year has an extra day, so decrement result if 4
        if (y1 == 4)
        {
            y1 = 3;
        }

        // If year was requested, compute and return it
        if (datePart == DatePart::Year)
        {
            return y400 * 400 + y100 * 100 + y4 * 4 + y1 + 1;
        }

        // n = day number within year
        n -= y1 * DaysPerYear;

        // If day-of-year was requested, return it
        if (datePart == DatePart::DayOfYear)
        {
            return n + 1;
        }

        // Leap year calculation looks different from IsLeapYear since y1, y4, and y100 are relative to year 1, not year 0.
        Boolean isLeapYear = (y1 == 3) && (y4 != 24 || y100 == 3);
        auto days = isLeapYear ? DaysToMonth366 : DaysToMonth365;

        // The 1-based month number.
        // All months have less than 32 days, so n >> 5 is a good conservative estimate for the month.
        Int32 monthNumber = (n >> 5) + 1;

        while (n >= days[monthNumber])
        {
            ++monthNumber;
        }

        // Return the month number, if it was requested.
        if (datePart == DatePart::Month)
        {
            return monthNumber;
        }

        // Return 1-based day-of-month.
        return n - days[monthNumber - 1] + 1;
    }

    DateTime DateTime::Add(const Double& value, const Double& scale) const
    {
        Int64 milliseconds = Int64(value * scale + Double(value >= 0 ? 0.5 : -0.5));

        if (milliseconds <= -MaxMillisecond || milliseconds >= MaxMillisecond)
        {
            throw Exception("ArgumentOutOfRangeException");
        }
        return AddTicks(milliseconds * TicksPerMillisecond);
    }

#pragma endregion
}
