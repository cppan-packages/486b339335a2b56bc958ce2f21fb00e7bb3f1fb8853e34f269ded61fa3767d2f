/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "SystemException.hpp"
#include "HResults.hpp"

namespace System
{
    /**
     * \brief The exception that is thrown when a requested method or operation is not implemented.
     */
    class NotImplementedException : SystemException
    {
    public:

#pragma region Public Contructors

        /**
         * \brief Initializes a new instance of the NotImplementedException class with default properties.
         */
        NotImplementedException();

        /**
         * \brief Initializes a new instance of the NotImplementedException class with a specified error message.
         * \param message The error message that explains the reason for the exception.
         */
        NotImplementedException(const String& message);

        /**
         * \brief Initializes a new instance of the NotImplementedException class with a specified error message and a reference to
         *        the inner exception that is the cause of this exception.
         * \param message The error message that explains the reason for the exception.
         * \param innerException The exception that is the cause of the current exception. If the inner parameter is not null, the 
         *                       current exception is raised in a catch block that handles the inner exception.
         */
        NotImplementedException(const String& message, Exception* innerException);

#pragma endregion
    };
}
