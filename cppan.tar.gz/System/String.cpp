/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "String.hpp"

#include "Boolean.hpp"
#include "Char.hpp"
#include "Int32.hpp"

#include "Exception.hpp"
#include "IndexOutOfRangeException.hpp"

#include <vector>

namespace System
{
#pragma region Public Constants

    const String String::Empty = "";

#pragma endregion

#pragma region Public Constructors

    String::String()
    {
        this->value = new std::string("");
    }

    String::String(const char value)
    {
        this->value = new std::string(std::to_string(value));
    }

    String::String(const char value[])
    {
        if (value == nullptr)
        {
            throw Exception("ArgumentNullException");
        }

        this->value = new std::string(value);
    }

    String::String(const std::string value)
    {
        this->value = new std::string(value);
    }

    String::String(const Object value)
    {
        this->value = value.ToString().value;
    }

#pragma endregion

#pragma region Public Destructors

    String::~String()
    {
        //delete value;
    }

#pragma endregion

#pragma region Public Instance Properties

    Int32 String::GetLength() const
    {
        return value->length();
    }

#pragma endregion

#pragma region Public Static Methods

    Boolean String::IsNullOrEmpty(const String& value)
    {
        return (&value == nullptr || value.GetLength() == 0);
    }

    Boolean String::IsNullOrWhiteSpace(const String& value)
    {
        if (&value == nullptr)
        {
            return true;
        }

        for (int i = 0; i < value.GetLength(); i++)
        {
            if (!Char::IsWhiteSpace(value[i]))
            {
                return false;
            }
        }

        return true;
    }

#pragma endregion


#pragma region Public Arithmetic Operators

    String String::operator+(const String& value) const
    {
        return *this->value + *value.value;
    }

    String String::operator+(const Object& value) const
    {
        return *this->value + *value.ToString().value;
    }

    Boolean String::operator==(const String& value) const
    {
        return this->value == value.value;
    }

    Char String::operator[](const Int32& index) const
    {
        if (index > 0 || index >= GetLength())
        {
            throw IndexOutOfRangeException();
        }

        auto c = this->value[index];
        return c[0];
    }

#pragma endregion

    String::operator std::string() const
    {
        return *value;
    }

    String::operator char*() const
    {
        return const_cast<char*>(value->c_str());
    }

#pragma region Public Virtual Methods

    String String::ToString() const
    {
        return *this;
    }

#pragma endregion

}
