/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Single.hpp"

#include "String.hpp"

#include <limits>
#include <string>

namespace System
{
#pragma region Public Constants

    const Single Single::Epsilon = std::numeric_limits<float>::epsilon();
    const Single Single::MaxValue = std::numeric_limits<float>::max();
    const Single Single::MinValue = -std::numeric_limits<float>::max();
    const Single Single::NaN = std::numeric_limits<float>::quiet_NaN();
    const Single Single::NegativeInfinity = -std::numeric_limits<float>::infinity();
    const Single Single::PositiveInfinity = std::numeric_limits<float>::infinity();

#pragma endregion

#pragma region Public Constructors

    Single::Single()
    {
        //this->value = 0.0F;
        Single(0.0F);
    }

    Single::Single(float value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Destructors

    Single::~Single()
    {
    }

#pragma endregion

#pragma region Public Overrided Operators

    String Single::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion
}
