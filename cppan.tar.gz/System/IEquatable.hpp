/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"
#include "Interface.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Boolean;
}

#pragma endregion

namespace System
{
    /**
     * \brief Defines a generalized method that a value type or class implements to create a type-specific method for determining
     *        equality of instances.
     * \tparam T The type of objects to compare.
     */
    template <typename T>
    interface DLLExport IEquatable
    {
    protected:
        ~IEquatable() = default;

    public:

        /**
         * \brief Indicates whether the current object is equal to another object of the same type. 
         * \param other An object to compare with this object.
         * \return true if the current object is equal to the other parameter; otherwise, false.
         */
        virtual Boolean Equals(const T& other) const = 0;
    };
}
