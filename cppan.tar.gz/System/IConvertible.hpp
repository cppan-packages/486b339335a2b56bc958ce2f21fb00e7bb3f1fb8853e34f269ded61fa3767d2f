/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Interface.hpp"

#pragma region Forward Declarations

namespace System
{
    class Object;
    class Type;
    enum TypeCode;

    struct Boolean;
    struct Byte;
    struct Char;
    struct Int16;
    struct Int32;
    struct Int64;
    struct Single;
    struct Double;

    class String;
    struct DateTime;

    struct IFormatProvider;
}

#pragma endregion

namespace System
{
    interface IConvertible
    {
    protected:
        ~IConvertible() = default;

    public:

#pragma region Public Virtual Instance Properties

        /**
        * \brief
        * \return
        */
        virtual TypeCode GetTypeCode() = 0;

#pragma endregion

#pragma Public Virtual Instance Methods

        /**
         * \brief 
         * \param provider 
         * \return 
         */
        virtual Boolean ToBoolean(const IFormatProvider& provider) = 0;

        /**
         * \brief 
         * \param provider 
         * \return 
         */
        virtual Byte ToByte(const IFormatProvider& provider) = 0;

        /**
         * \brief 
         * \param provider 
         * \return 
         */
        virtual Char ToChar(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual DateTime ToDateTime(const IFormatProvider& provider) = 0;

        //virtual Decimal ToDecimal(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual Double ToDouble(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual Int16 ToInt16(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual Int32 ToInt32(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual Int64 ToInt64(const IFormatProvider& provider) = 0;

        //virtual SByte ToSByte(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual Single ToSingle(const IFormatProvider& provider) = 0;

        /**
        * \brief
        * \param provider
        * \return
        */
        virtual String ToString(const IFormatProvider& provider) = 0;

        /**
         * \brief 
         * \param conversionType 
         * \param provider 
         * \return 
         */
        virtual Object ToType(Type conversionType, const IFormatProvider& provider) = 0;

        //virtual ushort ToUInt16(const IFormatProvider& provider);

        //virtual uint ToUInt32(const IFormatProvider& provider);

        //virtual ulong ToUInt64(const IFormatProvider& provider);

#pragma endregion
    };
}
