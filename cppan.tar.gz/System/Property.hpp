/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#pragma region Property Types

#define Property(type, var)\
	__declspec(property(put = set_##var, get = get_ ##var)) type var;\
	typedef type Type_##var

#define ReadonlyProperty(type, var)\
	__declspec(property(get = get_##var)) type var;\
	typedef const type Type_##var

#define WriteonlyProperty(type, var)\
	__declspec(property(put = set_##var)) type var;\
	typedef type Type_##var

#pragma endregion

#pragma region Accessors

#define Get(var)\
	Type_##var get_##var()

#define Set(var)\
	Type_##var& set_##var(const Type_##var& value)

#pragma endregion

#pragma region Auto Properties

#define AutoProperty(type, var)\
	Property(type, var);\
	Get(var){ return var; }\
	Set(var){ var = value; return var; }

#define AutoReadonlyProperty(type, var)\
	ReadonlyProperty(type, var);\
	Get(var){ return var; }

#define AutoWriteonlyProperty(type, var)\
	WriteonlyProperty(type, var);\
	Set(var){ var = value; return var; }

#pragma endregion
