﻿/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Byte;
    struct Int16;
    struct Int32;
    struct Int64;
    struct Single;
    struct Double;
}

#pragma endregion

namespace System
{
    /**
     * \brief Provides constants and static methods for trigonometric, logarithmic, and other common mathematical functions.
     */
    class DLLExport Math final
    {
    public:

#pragma region Public Constants

        /**
         * \brief Represents the natural logarithmic base, specified by the constant, e.
         */
        static const Double E;

        /**
         * \brief Represents the ratio of the circumference of a circle to its diameter, specified by the constant, π.
         */
        static const Double PI;

#pragma endregion

#pragma region Public Static Methods

        //static decimal Abs(decimal value);

        /**
         * \brief Returns the absolute value of a double-precision floating-point number.
         * \param value A number that is greater than or equal to Double.MinValue, but less than or equal to Double.MaxValue.
         * \return A double-precision floating-point number, x, such that 0 ≤ x ≤ Double.MaxValue.
         */
        static Double Abs(const Double& value);

        /**
         * \brief 
         * \param value 
         * \return 
         */
        static Int16 Abs(Int16 value);

        static Int32 Abs(Int32 value);

        static Int64 Abs(Int64 value);

        //static sbyte Abs(sbyte value);

        static Single Abs(Single value);

        static Double Acos(Double d);

        static Double Asin(Double d);

        static Double Atan(Double d);

        static Double Atan2(Double y, Double x);

        /**
         * \brief Produces the full product of two 32-bit numbers.
         * \param a The first number to multiply.
         * \param b The second number to multiply.
         * \return The number containing the product of the specified numbers.
         */
        static Int64 BigMul(const Int32& a, const Int32& b);

        //static decimal Ceiling(decimal d);
        //static double Ceiling(double a);

        /**
         * \brief Returns the cosine of the specified angle.
         * \param d An angle, measured in radians.
         * \return The cosine of d. If d is equal to NaN, NegativeInfinity, or PositiveInfinity, this method returns NaN.
         * \remarks The angle, d, must be in radians. Multiply by Math.PI/180 to convert degrees to radians.
         */
        static Double Cos(const Double& d);

        /**
         * \brief Returns the hyperbolic cosine of the specified angle.
         * \param value An angle, measured in radians.
         * \return The hyperbolic cosine of value. If value is equal to NegativeInfinity or PositiveInfinity, PositiveInfinity is
         *         returned. If value is equal to NaN, NaN is returned.
         */
        static Double Cosh(Double value);

        /**
         * \brief Calculates the quotient of two 32-bit signed integers and also returns the remainder in an output parameter.
         * \param a The dividend.
         * \param b The divisor.
         * \param result The remainder.
         * \return The quotient of the specified numbers.
         */
        static Int32 DivRem(const Int32& a, const Int32& b, Int32& result);

        //static long DivRem(long a, long b, out long result);

        //static double Exp(double d);

        //static decimal Floor(decimal d);

        //static double Floor(double d);

        //static double IEEERemainder(double x, double y);

        static Double Log(Double d);

        /**
         * \brief Returns the logarithm of a specified number in a specified base.
         * \param a The number whose logarithm is to be found.
         * \param newBase The base of the logarithm.
         * \return 
         */
        static Double Log(const Double& a, const Double& newBase);

        static Double Log10(Double d);

        /**
         * \brief Returns the larger of two 8-bit unsigned integers
         * \param val1 The first of two 8-bit unsigned integers to compare.
         * \param val2 The second of two 8-bit unsigned integers to compare.
         * \return Parameter val1 or val2, whichever is larger.
         */
        static Byte Max(Byte val1, Byte val2);

        //static decimal Max(decimal val1, decimal val2);

        //static double Max(double val1, double val2);

        //static short Max(short val1, short val2);

        //static int Max(int val1, int val2);

        //static long Max(long val1, long val2);

        //static sbyte Max(sbyte val1, sbyte val2);

        //static float Max(float val1, float val2);

        //static ushort Max(ushort val1, ushort val2);

        //static uint Max(uint val1, uint val2);

        //static ulong Max(ulong val1, ulong val2);

        //static byte Min(byte val1, byte val2);

        //static decimal Min(decimal val1, decimal val2);

        //static double Min(double val1, double val2);

        //static short Min(short val1, short val2);

        //static int Min(int val1, int val2);

        //static long Min(long val1, long val2);

        //static sbyte Min(sbyte val1, sbyte val2);

        //static float Min(float val1, float val2);

        //static ushort Min(ushort val1, ushort val2);

        //static uint Min(uint val1, uint val2);

        //static ulong Min(ulong val1, ulong val2);

        /**
         * \brief Returns a specified number raised to the specified power.
         * \param x A double-precision floating-point number to be raised to a power.
         * \param y A double-precision floating-point number that specifies a power.
         * \return The number x raised to the power y.
         */
        static Double Pow(Double x, Double y);

        //static decimal Round(decimal d);
        //static decimal Round(decimal d, int decimals);
        //static decimal Round(decimal d, int decimals, MidpointRounding mode);
        //static decimal Round(decimal d, MidpointRounding mode);
        //static double Round(double a);
        //static double Round(double value, int digits);
        //static double Round(double value, int digits, MidpointRounding mode);
        //static double Round(double value, MidpointRounding mode);

        //static int Sign(decimal value);
        //static int Sign(double value);
        //static int Sign(short value);

        /**
         * \brief 
         * \param value 
         * \return 
         */
        static Int32 Sign(const Int32& value);

        //static int Sign(long value);
        //static int Sign(sbyte value);
        //static int Sign(float value);

        static Double Sin(Double a);

        static Double Sinh(Double value);

        static Double Sqrt(Double d);

        static Double Tan(const Double& a);

        static Double Tanh(const Double& value);

        //static decimal Truncate(decimal d);
        //static double Truncate(double d);

#pragma endregion

    private:
        Math();
        ~Math();
    };
}
