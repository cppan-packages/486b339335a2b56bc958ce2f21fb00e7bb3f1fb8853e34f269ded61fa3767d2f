/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "HResults.hpp"

#include "Int32.hpp"

namespace System
{
#pragma region Public Static Constants

    const Int32 HResults::RO_E_CLOSED = 0x80000013;
    const Int32 HResults::E_BOUNDS = Int32(0x8000000B);
    const Int32 HResults::E_CHANGED_STATE = Int32(0x8000000C);
    const Int32 HResults::E_FAIL = Int32(0x80004005);
    const Int32 HResults::E_POINTER = Int32(0x80004003);
    const Int32 HResults::E_NOTIMPL = Int32(0x80004001);
    const Int32 HResults::REGDB_E_CLASSNOTREG = Int32(0x80040154);
    const Int32 HResults::COR_E_AMBIGUOUSMATCH = Int32(0x8000211D);
    const Int32 HResults::COR_E_APPDOMAINUNLOADED = Int32(0x80131014);
    const Int32 HResults::COR_E_APPLICATION = Int32(0x80131600);
    const Int32 HResults::COR_E_ARGUMENT = Int32(0x80070057);
    const Int32 HResults::COR_E_ARGUMENTOUTOFRANGE = Int32(0x80131502);
    const Int32 HResults::COR_E_ARITHMETIC = Int32(0x80070216);
    const Int32 HResults::COR_E_ARRAYTYPEMISMATCH = Int32(0x80131503);
    const Int32 HResults::COR_E_BADIMAGEFORMAT = Int32(0x8007000B);
    const Int32 HResults::COR_E_TYPEUNLOADED = Int32(0x80131013);
    const Int32 HResults::COR_E_CANNOTUNLOADAPPDOMAIN = Int32(0x80131015);
    const Int32 HResults::COR_E_COMEMULATE = Int32(0x80131535);
    const Int32 HResults::COR_E_CONTEXTMARSHAL = Int32(0x80131504);
    const Int32 HResults::COR_E_DATAMISALIGNED = Int32(0x80131541);
    const Int32 HResults::COR_E_TIMEOUT = Int32(0x80131505);
    const Int32 HResults::COR_E_CUSTOMATTRIBUTEFORMAT = Int32(0x80131605);
    const Int32 HResults::COR_E_DIVIDEBYZERO = Int32(0x80020012); // DISP_E_DIVBYZERO
    const Int32 HResults::COR_E_DUPLICATEWAITOBJECT = Int32(0x80131529);
    const Int32 HResults::COR_E_EXCEPTION = Int32(0x80131500);
    const Int32 HResults::COR_E_EXECUTIONENGINE = Int32(0x80131506);
    const Int32 HResults::COR_E_FIELDACCESS = Int32(0x80131507);
    const Int32 HResults::COR_E_FORMAT = Int32(0x80131537);
    const Int32 HResults::COR_E_INDEXOUTOFRANGE = Int32(0x80131508);
    const Int32 HResults::COR_E_INSUFFICIENTMEMORY = Int32(0x8013153D);
    const Int32 HResults::COR_E_INSUFFICIENTEXECUTIONSTACK = Int32(0x80131578);
    const Int32 HResults::COR_E_INVALIDCAST = Int32(0x80004002);
    const Int32 HResults::COR_E_INVALIDCOMOBJECT = Int32(0x80131527);
    const Int32 HResults::COR_E_INVALIDFILTERCRITERIA = Int32(0x80131601);
    const Int32 HResults::COR_E_INVALIDOLEVARIANTTYPE = Int32(0x80131531);
    const Int32 HResults::COR_E_INVALIDOPERATION = Int32(0x80131509);
    const Int32 HResults::COR_E_INVALIDPROGRAM = Int32(0x8013153A);
    const Int32 HResults::COR_E_KEYNOTFOUND = Int32(0x80131577);
    const Int32 HResults::COR_E_MARSHALDIRECTIVE = Int32(0x80131535);
    const Int32 HResults::COR_E_MEMBERACCESS = Int32(0x8013151A);
    const Int32 HResults::COR_E_METHODACCESS = Int32(0x80131510);
    const Int32 HResults::COR_E_MISSINGFIELD = Int32(0x80131511);
    const Int32 HResults::COR_E_MISSINGMANIFESTRESOURCE = Int32(0x80131532);
    const Int32 HResults::COR_E_MISSINGMEMBER = Int32(0x80131512);
    const Int32 HResults::COR_E_MISSINGMETHOD = Int32(0x80131513);
    const Int32 HResults::COR_E_MISSINGSATELLITEASSEMBLY = Int32(0x80131536);
    const Int32 HResults::COR_E_MULTICASTNOTSUPPORTED = Int32(0x80131514);
    const Int32 HResults::COR_E_NOTFINITENUMBER = Int32(0x80131528);
    const Int32 HResults::COR_E_PLATFORMNOTSUPPORTED = Int32(0x80131539);
    const Int32 HResults::COR_E_NOTSUPPORTED = Int32(0x80131515);
    const Int32 HResults::COR_E_NULLREFERENCE = Int32(0x80004003);
    const Int32 HResults::COR_E_OBJECTDISPOSED = Int32(0x80131622);
    const Int32 HResults::COR_E_OPERATIONCANCELED = Int32(0x8013153B);
    const Int32 HResults::COR_E_OUTOFMEMORY = Int32(0x8007000E);
    const Int32 HResults::COR_E_OVERFLOW = Int32(0x80131516);
    const Int32 HResults::COR_E_RANK = Int32(0x80131517);
    const Int32 HResults::COR_E_REFLECTIONTYPELOAD = Int32(0x80131602);
    const Int32 HResults::COR_E_RUNTIMEWRAPPED = Int32(0x8013153E);
    const Int32 HResults::COR_E_SAFEARRAYRANKMISMATCH = Int32(0x80131538);
    const Int32 HResults::COR_E_SAFEARRAYTYPEMISMATCH = Int32(0x80131533);
    const Int32 HResults::COR_E_SAFEHANDLEMISSINGATTRIBUTE = Int32(0x80131623);
    const Int32 HResults::COR_E_SECURITY = Int32(0x8013150A);
    const Int32 HResults::COR_E_SERIALIZATION = Int32(0x8013150C);
    const Int32 HResults::COR_E_SEMAPHOREFULL = Int32(0x8013152B);
    const Int32 HResults::COR_E_WAITHANDLECANNOTBEOPENED = Int32(0x8013152C);
    const Int32 HResults::COR_E_ABANDONEDMUTEX = Int32(0x8013152D);
    const Int32 HResults::COR_E_STACKOVERFLOW = Int32(0x800703E9);
    //const Int32 HResults::COR_E_SYNCHRONIZATIONLOCK = Int32(0x80131518);
    //const Int32 HResults::COR_E_SYSTEM = Int32(0x80131501);
    //const Int32 HResults::COR_E_TARGET = Int32(0x80131603);
    //const Int32 HResults::COR_E_TARGETINVOCATION = Int32(0x80131604);
    //const Int32 HResults::COR_E_TARGETPARAMCOUNT = Int32(0x8002000e);
    //const Int32 HResults::COR_E_THREADABORTED = Int32(0x80131530);
    //const Int32 HResults::COR_E_THREADINTERRUPTED = Int32(0x80131519);
    //const Int32 HResults::COR_E_THREADSTATE = Int32(0x80131520);
    //const Int32 HResults::COR_E_THREADSTOP = Int32(0x80131521);
    //const Int32 HResults::COR_E_THREADSTART = Int32(0x80131525);
    //const Int32 HResults::COR_E_TYPEACCESS = Int32(0x80131543);
    //const Int32 HResults::COR_E_TYPEINITIALIZATION = Int32(0x80131534);
    //const Int32 HResults::COR_E_TYPELOAD = Int32(0x80131522);
    //const Int32 HResults::COR_E_ENTRYPOINTNOTFOUND = Int32(0x80131523);
    //const Int32 HResults::COR_E_DLLNOTFOUND = Int32(0x80131524);
    //const Int32 HResults::COR_E_UNAUTHORIZEDACCESS = Int32(0x80070005);
    //const Int32 HResults::COR_E_UNSUPPORTEDFORMAT = Int32(0x80131523);
    //const Int32 HResults::COR_E_VERIFICATION = Int32(0x8013150D);
    //const Int32 HResults::COR_E_HOSTPROTECTION = Int32(0x80131640);
    //const Int32 HResults::CORSEC_E_MIN_GRANT_FAIL = Int32(0x80131417);
    //const Int32 HResults::CORSEC_E_NO_EXEC_PERM = Int32(0x80131418);
    //const Int32 HResults::CORSEC_E_POLICY_EXCEPTION = Int32(0x80131416);
    //const Int32 HResults::CORSEC_E_XMLSYNTAX = Int32(0x80131418);
    //const Int32 HResults::NTE_FAIL = Int32(0x80090020);
    //const Int32 HResults::CORSEC_E_CRYPTO = Int32(0x80131430);
    //const Int32 HResults::CORSEC_E_CRYPTO_UNEX_OPER = Int32(0x80131431);
    //const Int32 HResults::DISP_E_OVERFLOW = Int32(0x8002000a);
    //const Int32 HResults::FUSION_E_REF_DEF_MISMATCH = Int32(0x80131040);
    //const Int32 HResults::FUSION_E_INVALID_NAME = Int32(0x80131047);
    //const Int32 HResults::TYPE_E_TYPEMISMATCH = Int32(0x80028ca0);

#pragma endregion
}
