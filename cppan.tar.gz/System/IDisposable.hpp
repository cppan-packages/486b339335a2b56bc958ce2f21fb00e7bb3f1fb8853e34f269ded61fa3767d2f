/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Interface.hpp"

namespace System
{
    /**
     * \brief Provides a mechanism for releasing unmanaged resources.
     */
    interface DLLExport IDisposable
    {
    protected:
        ~IDisposable() = default;
    public:

        /**
         * \brief Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
         */
        virtual void Dispose() = 0;
    };
}
