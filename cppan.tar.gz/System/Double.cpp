/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Double.hpp"

#include "Boolean.hpp"
#include "String.hpp"

#include <limits>

namespace System
{
#pragma region Public Constants

    const Double Double::Epsilon = std::numeric_limits<double>::epsilon();
    const Double Double::MaxValue = std::numeric_limits<double>::max();
    const Double Double::MinValue = -std::numeric_limits<double>::max();
    const Double Double::NaN = std::numeric_limits<double>::quiet_NaN();
    const Double Double::NegativeInfinity = -std::numeric_limits<double>::infinity();
    const Double Double::PositiveInfinity = std::numeric_limits<double>::infinity();

#pragma endregion

    Double::Double()
    {
        this->value = 0.0;
    }

    Double::Double(double value)
    {
        this->value = value;
    }

    Double::~Double()
    {
    }

#pragma region Public Static Methods

    Boolean Double::IsInfinity(const Double& d)
    {
        return IsPositiveInfinity(d) || IsNegativeInfinity(d);
    }

    Boolean Double::IsPositiveInfinity(const Double& d)
    {
        return d == PositiveInfinity;
    }

    Boolean Double::IsNegativeInfinity(const Double& d)
    {
        return d == NegativeInfinity;
    }

    Boolean Double::IsNaN(const Double& d)
    {
        return isnan(d);
    }

#pragma endregion

    String Double::ToString() const
    {
        return std::to_string(value);
    }

#pragma region Public Operators

    Double& Double::operator+=(const Double& rhs)
    {
        this->value = this->value + rhs.value;
        return *this;
    }

    Double& Double::operator-=(const Double& rhs)
    {
        this->value = this->value - rhs.value;
        return *this;
    }

    Double& Double::operator*=(const Double& rhs)
    {
        this->value = this->value * rhs.value;
        return *this;
    }

    Double& Double::operator/=(const Double& rhs)
    {
        this->value = this->value / rhs.value;
        return *this;
    }

#pragma endregion

#pragma region Public Conversion Operators

    Double::operator double() const
    {
        return value;
    }

#pragma endregion
}
