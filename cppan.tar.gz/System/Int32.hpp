/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"
#include "IComparable.hpp"
#include "IEquatable.hpp"

#include <cstdint>

namespace System
{
    class String;

    /**
     * \brief Represents a 32-bit signed integer.
     */
    struct DLLExport Int32 final : public Object, IComparable<>, IComparable<Int32>, IEquatable<Int32>
    {
    private:
        int32_t value;

    public:

#pragma region Public Constants

        /**
         * \brief Represents the largest possible value of an Int32. This field is constant.
         */
        static const Int32 MaxValue;

        /**
         * \brief Represents the smallest possible value of Int32. This field is constant.
         */
        static const Int32 MinValue;

#pragma endregion

#pragma region Public Constructors

        Int32();
        Int32(int32_t value);

#pragma endregion

#pragma region Public Destructor

        ~Int32();

#pragma endregion

#pragma region Public Overrided Instance Methods

        Int32 CompareTo(const Object& other) const override;
        Int32 CompareTo(const Int32& other) const override;

        Boolean Equals(const Int32& value) const override;
        Boolean Equals(const Object& obj) const override;

        Int32 GetHashCode() const override;

        String ToString() const override;

#pragma endregion

#pragma region Public Operators

        // Arithmetic operators shouldn't be inlined to avoid ambiguity between primitive types.

        Int32& operator+=(const Int32& rhs);
        Int32& operator-=(const Int32& rhs);
        Int32& operator*=(const Int32& rhs);
        Int32& operator/=(const Int32& rhs);

        Int32& operator++();
        Int32 operator++(int) const;

#pragma endregion

#pragma region Public Conversion Operators

        operator int32_t() const;

#pragma endregion
    };
}
