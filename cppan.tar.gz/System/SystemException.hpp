/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Exception.hpp"

namespace System
{
    class SystemException : public Exception
    {
    public:

#pragma region Public Constructors

        /**
         * \brief 
         */
        explicit SystemException();

        /**
         * \brief 
         * \param message 
         */
        explicit SystemException(const String& message);

        /**
         * \brief 
         * \param message 
         * \param innerException 
         */
        explicit SystemException(const String& message, Exception* innerException);

#pragma endregion

    protected:

#pragma region Protected Constructors

        //SystemException(SerializationInfo info, StreamingContext context);

#pragma endregion
    };
}
