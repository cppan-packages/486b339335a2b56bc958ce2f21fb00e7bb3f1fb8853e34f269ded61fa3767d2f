/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Boolean.hpp"

#include "Int32.hpp"
#include "String.hpp"
#include "Exception.hpp"

namespace System
{
#pragma region Private Constants

    const Int32 Boolean::True = 1;

    const Int32 Boolean::False = 0;

#pragma endregion

#pragma region Public Constants

    const String Boolean::TrueString = "True";

    const String Boolean::FalseString = "False";

#pragma endregion

#pragma region Public Constructors

    Boolean::Boolean()
    {
        this->value = false;
    }

    Boolean::Boolean(bool value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Destructors

    Boolean::~Boolean()
    {
    }

#pragma endregion

#pragma region Public Instance Methods

    Boolean Boolean::Parse(String value)
    {
        if (&value == nullptr)
        {
            throw Exception("ArgumentNullException");
        }

        return true;
    }

    Boolean Boolean::TryParse(String value, Boolean& result)
    {
        return false;
    }

#pragma endregion

#pragma region Public Overrided Instance Methods

    Int32 Boolean::GetHashCode() const
    {
        return value ? True : False;
    }

    String Boolean::ToString() const
    {
        return value ? TrueString : FalseString;
    }

#pragma endregion

    Boolean::operator bool() const
    {
        return value;
    }
}
