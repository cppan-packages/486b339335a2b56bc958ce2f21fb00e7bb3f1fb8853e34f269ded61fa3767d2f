/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Console.hpp"

#include "Char.hpp"
#include "Int32.hpp"
#include "Int64.hpp"
#include "Single.hpp"
#include "Double.hpp"
#include "String.hpp"
#include "ConsoleColor.hpp"

#include <iostream>

namespace System
{
#pragma region Private Static Variables

    ConsoleColor Console::consoleColor = Black;

#pragma endregion

#pragma region Private Constructors

    Console::Console()
    {
    }

#pragma endregion

#pragma region Private Destructors

    Console::~Console()
    {
    }

#pragma endregion

    ConsoleColor Console::GetBackgroundColor()
    {
        return consoleColor;
    }

    ConsoleColor Console::SetBackgroundColor(ConsoleColor value)
    {
        consoleColor = value;
        return consoleColor;
    }

#pragma region Public Static Methods

    String Console::ReadLine()
    {
        std::string value;
        std::cin >> value;
        return value;
    }

    void Console::WriteLine()
    {
        WriteLine(String::Empty);
    }

    void Console::WriteLine(const Char value)
    {
        WriteLine(value.ToString());
    }

    void Console::WriteLine(const Double value)
    {
        WriteLine(value.ToString());
    }

    /*void Console::WriteLine(const Boolean value)
    {
        WriteLine(value.ToString());
    }*/

    //void Console::WriteLine(bool value)
    //{
    //    if (value)
    //    {
    //        WriteLine("True");
    //    }
    //    else
    //    {
    //        WriteLine("False");
    //    }
    //}

    void Console::WriteLine(const Int32 value)
    {
        WriteLine(value.ToString());
    }

    void Console::WriteLine(const Int64 value)
    {
        WriteLine(value.ToString());
    }

    void Console::WriteLine(const Object& value)
    {
        WriteLine(value.ToString());
    }

    void Console::WriteLine(const Single value)
    {
        WriteLine(value.ToString());
    }

    void Console::WriteLine(const String& value)
    {
        std::cout << std::string(value) << std::endl;
    }

#pragma endregion
}
