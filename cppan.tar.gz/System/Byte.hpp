/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"
#include "IEquatable.hpp"
#include "IComparable.hpp"

#include <cstdint>

namespace System
{
    /**
     * \brief Represents an 8-bit unsigned integer.
     */
    struct Byte final : public Object, IComparable<>, IComparable<Byte>, IEquatable<Byte>
    {
    private:
        uint8_t value;

    public:

#pragma region Public Constants

        static const Byte MaxValue;
        static const Byte MinValue;

#pragma endregion

#pragma region Public Constuctors

        Byte();
        Byte(uint8_t value);

#pragma endregion

#pragma region Public Destructors

        ~Byte();

#pragma endregion

#pragma region Public Static Methods

        /**
         * \brief Converts the string representation of a number to its Byte equivalent.
         * \param s A string that contains a number to convert. The string is interpreted using the Integer style.
         * \return A byte value that is equivalent to the number contained in s.
         */
        static Byte Parse(const String& s);

        /**
         * \brief Tries to convert the string representation of a number to its Byte equivalent, and returns a value that indicates
         *        whether the conversion succeeded.
         * \param s A string that contains a number to convert. The string is interpreted using the Integer style.
         * \param result When this method returns, contains the Byte value equivalent to the number contained in s if the 
         *               conversion succeeded, or zero if the conversion failed. This parameter is passed uninitialized; any value
         *               originally supplied in result will be overwritten.
         * \return true if s was converted successfully; otherwise, false.
         */
        static Boolean TryParse(const String& s, Byte& result);

#pragma endregion

#pragma region Public Overriden Instance Methods

        Boolean Equals(const Object& obj) const override;
        Boolean Equals(const Byte& other) const override;

        Int32 CompareTo(const Object& other) const override;
        Int32 CompareTo(const Byte& other) const override;

        Int32 GetHashCode() const override;

        String ToString() const override;

#pragma endregion

        Boolean operator>=(const Byte& b) const;
    };
}
