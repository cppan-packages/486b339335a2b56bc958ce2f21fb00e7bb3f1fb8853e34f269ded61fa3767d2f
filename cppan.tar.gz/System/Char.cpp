/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "Char.hpp"

#include "Int32.hpp"
#include "Convert.hpp"
#include "ArgumentException.hpp"

namespace System
{
    Char::Char()
    {
        this->value = 0;
    }

    Char::Char(char value)
    {
        this->value = value;
    }

    Char::~Char()
    {
    }

#pragma region Public Static Methods

    Boolean Char::IsWhiteSpace(const Char c)
    {
        if (IsLatin1(c))
        {
            return IsWhiteSpaceLatin1(c);
        }

        return IsWhiteSpaceLatin1(c);
        //return CharUnicodeInfo.IsWhiteSpace(c);
    }

#pragma endregion

#pragma region Public Overrided Instance Methods

    Int32 Char::CompareTo(const Object& other) const
    {
        if (&other == nullptr)
        {
            return 1;
        }

        if (!Convert::Is<Char>(other))
        {
            throw ArgumentException("The argument must be of type Char.", "other");
        }

        return this->value - Convert::Cast<Object, Char>(other).value;
    }

    Int32 Char::CompareTo(const Char& other) const
    {
        return this->value - other.value;
    }

    Boolean Char::Equals(const Object& obj) const
    {
        if (!Convert::Is<Char>(obj))
        {
            return false;
        }

        return this->value == Convert::Cast<Object, Char>(obj).value;
    }

    Boolean Char::Equals(const Char& other) const
    {
        return this->value == other.value;
    }

    Int32 Char::GetHashCode() const
    {
        return int(this->value) | (int(this->value) << 16);
    }

    String Char::ToString() const
    {
        return std::to_string(value);
    }

#pragma endregion

    Boolean Char::operator==(const Char value) const
    {
        return this->value == value.value;
    }

    Boolean Char::operator<=(const Char value) const
    {
        return this->value <= value.value;
    }

    Boolean Char::operator>=(const Char value) const
    {
        return this->value >= value.value;
    }

#pragma region Private Static Methods

    Boolean Char::IsLatin1(const Char value)
    {
        return (value <= '\x00ff');
    }

    Boolean Char::IsWhiteSpaceLatin1(const Char value)
    {
        // There are characters which belong to UnicodeCategory.Control but are considered as white spaces.
        // We use code point comparisons for these characters here as a temporary fix.

        // U+0009 = <control> HORIZONTAL TAB
        // U+000a = <control> LINE FEED
        // U+000b = <control> VERTICAL TAB
        // U+000c = <contorl> FORM FEED
        // U+000d = <control> CARRIAGE RETURN
        // U+0085 = <control> NEXT LINE
        // U+00a0 = NO-BREAK SPACE
        if ((value == ' ') || (value >= '\x0009' && value <= '\x000d') || value == '\x00a0' || value == '\x0085')
        {
            return true;
        }

        return false;
    }

#pragma endregion
}
