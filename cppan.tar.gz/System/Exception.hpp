/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "Object.hpp"
#include "Int32.hpp"
#include "String.hpp"

#include <stdexcept>

namespace System
{
    /**
     * \brief Represents errors that occur during application execution.
     */
    class Exception : public Object, public std::runtime_error
    {
    public:

#pragma region Public Constructors

        explicit Exception();

        /**
        * \brief Initializes a new instance of the Exception class with a specified error message.
        * \param message The message that describes the error.
        */
        explicit Exception(const String& message);


        /**
        * \brief Initializes a new instance of the Exception class with a specified error message and a reference to the inner
        *        exception that is the cause of this exception.
        * \param message The error message that explains the reason for the exception.
        * \param innerException The exception that is the cause of the current exception, or a null reference if no inner exception is
        *                       specified.
        */
        explicit Exception(const String& message, Exception* innerException);

#pragma endregion

#pragma region Public Destructor

        ~Exception();

#pragma endregion

#pragma region Public Instance Properties

        Exception GetInnerException() const;

        /**
         * \brief Gets HRESULT, a coded numerical value that is assigned to a specific exception.
         * \return
         */
        Int32 GetHResult() const;

        //MethodBase TargetSite{ get; }

#pragma endregion

#pragma region Public Virtual Instance Properties

        //virtual IDictionary Data{ get; }

        virtual String GetHelpLink() const;
        virtual void SetHelpLink(const String& value);

        virtual String GetMessage() const;

        virtual String GetSource() const;
        virtual void SetSource(const String& value);

        virtual String GetStackTrace() const;

#pragma endregion

        virtual Exception GetBaseException();

        //virtual void GetObjectData(SerializationInfo info, StreamingContext context);
        //new Type GetType();

#pragma region Public Overriden Instance Methods

        char const* what() const override;

        Boolean Equals(const Object& obj) const override;

        Int32 GetHashCode() const override;

        String ToString() const override;

#pragma endregion

    protected:

        /**
         * \brief Sets HRESULT, a coded numerical value that is assigned to a specific exception.
         * \param value
         */
        void SetHResult(const Int32& value);

        //Exception(SerializationInfo info, StreamingContext context);
        //event EventHandler<SafeSerializationEventArgs> SerializeObjectState;

    private:

#pragma region Private Instance Variables

        String className;
        //MethodBase exceptionMethod;
        String exceptionMethodString;
        String message;
        //IDictionary data;
        String helpURL;
        Object stackTrace;
        Object watsonBuckets;
        String stackTraceString;
        String remoteStackTraceString;
        Int32 remoteStackIndex;
        Object dynamicMethods;

        String source;

        Exception* innerException;

#pragma endregion
    };
}
