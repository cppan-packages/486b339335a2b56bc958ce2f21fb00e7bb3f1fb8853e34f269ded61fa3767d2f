/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "ICloneable.hpp"
#include "Exception.hpp"

#include <tuple>
#include <functional>

namespace System
{
    /**
     * \brief Represents a delegate, which is a data structure that refers to a static method or to a class instance and an 
     *        instance method of that class.
     * \tparam TResult The return type of the delegate's method signature.
     * \tparam TArgs The argument types of the delegate's method signature.
     */
    template <typename TResult, typename... TArgs>
    class Delegate : public ICloneable
    {
    public:

#pragma region Type Definitions

        using Function = std::function<TResult(TArgs ...)>;
        //using Result = std::tuple<TResult>;
        using Args = std::tuple<TArgs...>;

        using Result = TResult;

#pragma endregion

#pragma region Public Constructors

        /**
         * \brief Initializes an empty delegate.
         */
        //explicit Delegate();

        /**
         * \brief 
         * \param function 
         */
        Delegate(Function function);

#pragma endregion

#pragma region Public Destructor

        virtual ~Delegate();

#pragma endregion

#pragma region Public Instance Properties

        /**
         * \brief Gets the class instance on which the current delegate invokes the instance method.
         * \return The object on which the current delegate invokes the instance method, if the delegate represents an instance 
         *         method; null if the delegate represents a static method.
         */
        Object GetTarget() const;

#pragma endregion

#pragma region Public Instance Methods

        /**
         * \brief Invokes the method the delegate points to.
         * \param args The arguments of the method the delegate points to.
         * \return The return value of the method the delegate points to.
         */
        TResult Invoke(TArgs ... args);

#pragma endregion

#pragma region Public Instance Overriden Methods

        Object Clone() override;

#pragma endregion

#pragma region Public Operators

        virtual TResult operator()(TArgs ... args);

#pragma endregion

        //TODO: Lixo.
        template <typename TFunction>
        static Delegate<TResult, TArgs...> Build(TFunction&& function, TResult&& result, TArgs&&... args);

    private:
        std::function<TResult(TArgs ...)> function;
    };

#pragma region Public Constructors

    template <typename TResult, typename ... TArgs>
    Delegate<TResult, TArgs...>::Delegate(Function function)
    {
        this->function = function;
    }

#pragma endregion

#pragma region Public Destructor

    template <typename TResult, typename ... TArgs>
    Delegate<TResult, TArgs...>::~Delegate()
    {
    }

#pragma endregion

#pragma region Public Instance Properties

    template <typename TResult, typename ... TArgs>
    Object Delegate<TResult, TArgs...>::GetTarget() const
    {
        throw Exception("NotImplementedExcepetion");
    }

#pragma endregion

#pragma region Public Instance Methods

    template <typename TResult, typename ... TArgs>
    TResult Delegate<TResult, TArgs...>::Invoke(TArgs ... args)
    {
        return function(args...);
    }

#pragma endregion

#pragma region Public Instance Overriden Methods

    template <typename TResult, typename ... TArgs>
    Object Delegate<TResult, TArgs...>::Clone()
    {
        throw Exception("NotImplementedExcepetion");
    }

#pragma endregion

#pragma region Public Operators

    template <typename TResult, typename ... TArgs>
    TResult Delegate<TResult, TArgs...>::operator()(TArgs ... args)
    {
        return Invoke(args...);
    }

#pragma endregion


    template <typename TResult, typename ... TArgs>
    template <typename TFunction>
    Delegate<TResult, TArgs...> Delegate<TResult, TArgs...>::Build(TFunction&& function, TResult&& result, TArgs&&... args)
    {
        return Delegate<TResult, TArgs...>(std::forward<TFunction>(function), std::forward<TResult>(result),
                                           std::forward<TArgs>(args)...);
    }
}
