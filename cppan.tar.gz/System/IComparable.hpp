/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"
#include "Interface.hpp"

namespace System
{
    class Object;
    struct Int32;

    /**
     * \brief Defines a generalized comparison method that a struct or class implements to create a type-specific comparison method
     *        for ordering or sorting its instances.\n
     *        If no type is specified, defines a generalized type-specific comparison method that a value type or class implements
     *        to order or sort its instances.
     * \tparam T The type of object to compare. Default is Object.
     */
    template <typename T = Object>
    interface DLLExport IComparable
    {
    protected:
        ~IComparable() = default;

    public:

        /**
         * \brief Compares the current instance with another object of the same type and returns an integer that indicates whether
         *        the current instance precedes, follows, or occurs in the same position in the sort order as the other object.
         * \param other An object to compare with this instance.
         * \return A value that indicates the relative order of the objects being compared. The return value has these meanings:\n
         *         Less than zero: This instance precedes other in the sort order.\n
         *         Zero: This instance occurs in the same position in the sort order as other.\n
         *         Greater than zero: This instance follows other in the sort order.
         */
        virtual Int32 CompareTo(const T& other) const = 0;
    };
}
