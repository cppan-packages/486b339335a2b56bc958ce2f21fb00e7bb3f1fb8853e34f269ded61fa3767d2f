/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#include "IndexOutOfRangeException.hpp"

namespace System
{
#pragma region Public Constructors

    IndexOutOfRangeException::IndexOutOfRangeException() :
        SystemException()
    {
    }

    IndexOutOfRangeException::IndexOutOfRangeException(const String& message) :
        SystemException(message)
    {
    }

    IndexOutOfRangeException::IndexOutOfRangeException(const String& message, Exception* innerException) :
        SystemException(message, innerException)
    {
    }

#pragma endregion
}
