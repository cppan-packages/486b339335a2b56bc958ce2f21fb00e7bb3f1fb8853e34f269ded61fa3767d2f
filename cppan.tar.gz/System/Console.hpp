/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "DLL.hpp"

#include "Object.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Char;
    struct Int32;
    struct Int64;
    struct Single;
    struct Double;

    class String;

    enum ConsoleColor;
}

#pragma endregion

namespace System
{
    /**
     * \brief Represents the standard input, output, and error streams for console applications. 
     *        This class cannot be inherited.
     */
    class DLLExport Console final : public Object
    {
    public:

#pragma region Public Static Properties

        /**
         * \brief Gets the background color of the console.
         * \return The background color of the console.
         */
        static ConsoleColor GetBackgroundColor();


        /**
         * \brief Sets the background color of the console.
         * \param consoleColor A value that specifies the background color of the console; that is, the color that appears behind
         *                     each character. The default is black.
         * \return The background color of the console.
         */
        static ConsoleColor SetBackgroundColor(ConsoleColor consoleColor);

#pragma endregion

#pragma region Public Static Methods

        /**
         * \brief Reads the next line of characters from the standard input stream.
         * \return The next line of characters from the input stream, or null if no more lines are available.
         */
        static String ReadLine();

        /**
         * \brief Writes the current line terminator to the standard output stream.
         */
        static void WriteLine();

        //TODO: Enabling this method causes the C++ compiler ambiguity when converting a const char* to String or Boolean.
        //static void WriteLine(const Boolean value);

        /**
         * \brief Writes the specified Unicode character, followed by the current line terminator, value to the standard output 
         *        stream.
         * \param value The value to write.
         */
        static void WriteLine(const Char value);

        //static void WriteLine(char* buffer);
        //static void WriteLine(char* buffer, int index, int count);
        //static void WriteLine(decimal value);

        /**
         * \brief Writes the text representation of the specified double-precision floating-point value, followed by the current 
         *        line terminator, to the standard output stream.
         * \param value The value to write.
         */
        static void WriteLine(const Double value);

        /**
         * \brief Writes the text representation of the specified 32-bit signed integer value, followed by the current line
         *        terminator, to the standard output stream.
         * \param value The value to write.
         */
        static void WriteLine(const Int32 value);

        /**
         * \brief Writes the text representation of the specified 64-bit signed integer value, followed by the current line 
         *        terminator, to the standard output stream.
         * \param value The value to write.
         */
        static void WriteLine(const Int64 value);

        /**
         * \brief Writes the text representation of the specified object, followed by the current line terminator, to the standard
         *        output stream.
         * \param value The value to write.
         */
        static void WriteLine(const Object& value);

        /**
         * \brief Writes the text representation of the specified single-precision floating-point value, followed by the current 
         *        line terminator, to the standard output stream.
         * \param value The value to write.
         */
        static void WriteLine(const Single value);

        /**
         * \brief Writes the specified string value, followed by the current line terminator, to the standard output stream.
         * \param value The value to write.
         */
        static void WriteLine(const String& value);

        //static void WriteLine(string format, object arg0);
        //static void WriteLine(string format, object arg0, object arg1);
        //static void WriteLine(string format, object arg0, object arg1, object arg2);
        //static void WriteLine(string format, params object[] arg);
        //static void WriteLine(uint value);
        //static void WriteLine(ulong value);

#pragma endregion

    private:
        Console();
        ~Console();

        static ConsoleColor consoleColor;
    };
}
