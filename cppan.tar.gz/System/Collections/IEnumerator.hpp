/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../DLL.hpp"
#include "../Interface.hpp"

#pragma region Forward Declarations

namespace System
{
    class Object;
    struct Boolean;
}

#pragma endregion

namespace System::Collections
{
    /**
     * \brief Supports a simple iteration over a non-generic collection.
     */
    interface DLLExport IEnumerator
    {
    public:
#pragma region Public Virtual Instance Properties

        /**
         * \brief Gets the element in the collection at the current position of the enumerator.
         * \return The element in the collection at the current position of the enumerator.
         */
        virtual Object& GetCurrent() const = 0;

#pragma endregion

#pragma region Public Virtual Instance Methods

        /**
         * \brief Advances the enumerator to the next element of the collection.
         * \return true if the enumerator was successfully advanced to the next element; false if the enumerator has passed the end 
         *         of the collection.
         */
        virtual Boolean MoveNext() = 0;

        /**
         * \brief Sets the enumerator to its initial position, which is before the first element in the collection.
         */
        virtual void Reset() = 0;

#pragma endregion

    protected:
        ~IEnumerator() = default;
    };
}
