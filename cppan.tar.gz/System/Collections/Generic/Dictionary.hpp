﻿/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../../Object.hpp"
#include <map>

namespace System::Collections::Generic
{
    /**
     * \brief Represents a collection of keys and values.
     * \tparam TKey The type of the keys in the dictionary.
     * \tparam TValue The type of the values in the dictionary.
     */
    template <typename TKey, typename TValue>
    class DLLExport Dictionary : public Object
    {
    private:
        std::map<TKey, TValue> value;

    protected:
        //protected Dictionary(SerializationInfo info, StreamingContext context);

    public:

        /**
         * \brief Initializes a new instance of the Dictionary<TKey, TValue> class that is empty, has the default initial capacity,
         *        and uses the default equality comparer for the key type.
         */
        Dictionary();

        Dictionary(const std::map<TKey, TValue>& value);

#pragma region Public Instance Properties

        //IEqualityComparer<TKey> Comparer{ get; }
        //int Count{ get; }
        //TValue this[TKey key] { get; set; }
        //Dictionary<TKey, TValue>.KeyCollection Keys{ get; }
        //Dictionary<TKey, TValue>.ValueCollection Values{ get; }

#pragma endregion

#pragma region Public Instance Methods

        /**
         * \brief Adds the specified key and value to the dictionary.
         * \param key The key of the element to add.
         * \param value The value of the element to add.
         */
        void Add(TKey key, TValue value);

        /**
         * \brief Removes all keys and values from the Dictionary<TKey, TValue>.
         */
        void Clear();

        /**
         * \brief Determines whether the Dictionary<TKey, TValue> contains the specified key.
         * \param key The key to locate in the Dictionary<TKey, TValue>.
         * \return true if the Dictionary<TKey, TValue> contains an element with the specified key; otherwise, false.
         * \remarks This method approaches an O(1) operation.
         */
        bool ContainsKey(TKey key);

        //bool ContainsValue(TValue value);
        //Dictionary<TKey, TValue>.Enumerator GetEnumerator();
        //virtual void GetObjectData(SerializationInfo info, StreamingContext context);
        //virtual void OnDeserialization(object sender);

        /**
         * \brief Removes the value with the specified key from the Dictionary<TKey, TValue>.
         * \param key The key of the element to remove.
         * \return true if the element is successfully found and removed; otherwise, false. This method returns false if key is not
         *         found in the Dictionary<TKey, TValue>.
         * \remarks If the Dictionary<TKey, TValue> does not contain an element with the specified key, the 
         *          Dictionary<TKey, TValue> remains unchanged. No exception is thrown.\n
         *          This method approaches an O(1) operation.
         */
        bool Remove(TKey key);

        //bool TryGetValue(TKey key, out TValue value);

#pragma endregion

        TValue& operator[](const TKey& key);
    };

#pragma region Public Constructors

    template <typename TKey, typename TValue>
    Dictionary<TKey, TValue>::Dictionary()
    {
        value = std::map<TKey, TValue>();
    }

    template <typename TKey, typename TValue>
    Dictionary<TKey, TValue>::Dictionary(const std::map<TKey, TValue>& value)
    {
        this->value = value;
    }

#pragma endregion

#pragma region Public Instance Methods

    template <typename TKey, typename TValue>
    void Dictionary<TKey, TValue>::Add(TKey key, TValue value)
    {
        this->value.insert(std::make_pair(key, value));
    }

    template <typename TKey, typename TValue>
    void Dictionary<TKey, TValue>::Clear()
    {
        this->value.clear();
    }

    template <typename TKey, typename TValue>
    bool Dictionary<TKey, TValue>::ContainsKey(TKey key)
    {
        return this->value.find(key) != this->value.end() ? true : false;
    }

    template <typename TKey, typename TValue>
    bool Dictionary<TKey, TValue>::Remove(TKey key)
    {
        for (std::map<TKey, TValue>::iterator it = this->value.begin(); it != this->value.end(); ++it)
        {
            TKey currentKey = it->first;

            if (currentKey == key)
            {
                this->value.erase(it);
                return true;
            }
        }
        return false;
    }

    template <typename TKey, typename TValue>
    TValue& Dictionary<TKey, TValue>::operator[](const TKey& key)
    {
        return this->value[key];
    }

#pragma endregion
}
