﻿/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../../DLL.hpp"
#include "../../Interface.hpp"

namespace System
{
    struct Int32;
}

namespace System::Collections::Generic
{
    /**
     * \brief Defines a method that a type implements to compare two objects.
     * \tparam T The type of objects to compare.
     */
    template <typename T>
    interface DLLExport IComparer
    {
        /**
         * \brief Compares two objects and returns a value indicating whether one is less than, equal to, or greater than the
         *        other.
         * \param x The first object to compare.
         * \param y The second object to compare.
         * \return A signed integer that indicates the relative values of x and y, as shown in the following table.
         */
        virtual Int32 Compare(T x, T y) = 0;
    };
}
