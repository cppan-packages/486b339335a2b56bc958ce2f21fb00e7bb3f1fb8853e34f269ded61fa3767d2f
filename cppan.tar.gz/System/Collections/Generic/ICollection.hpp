﻿/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "IEnumerable.hpp"

#include "../IEnumerable.hpp"

#include "../../Interface.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Boolean;
    struct Int32;
}

#pragma endregion

namespace System::Collections::Generic
{
    /**
     * \brief Defines methods to manipulate generic collections.
     * \tparam T The type of the elements in the collection.
     */
    template <typename T>
    interface DLLExport ICollection : Collections::IEnumerable, IEnumerable<T>
    {
    protected:
        ~ICollection() = default;

    public:
#pragma region Public Virtual Properties

        /**
         * \brief Gets the number of elements contained in the ICollection<T>.
         * \return The number of elements contained in the ICollection<T>.
         */
        virtual Int32 GetCount() = 0;

        /**
         * \brief Gets a value indicating whether the ICollection<T> is read-only.
         * \return true if the ICollection<T> is read-only; otherwise, false.
         */
        virtual Boolean GetIsReadOnly() = 0;

#pragma endregion

#pragma region Public Virtual Instance Methods

        /**
         * \brief Adds an item to the ICollection<T>.
         * \param item The object to add to the ICollection<T>.
         */
        virtual void Add(const T& item) = 0;

        /**
         * \brief Removes all items from the ICollection<T>.
         */
        virtual void Clear() = 0;

        /**
         * \brief Determines whether the ICollection<T> contains a specific value.
         * \param item The object to locate in the ICollection<T>.
         * \return
         */
        virtual Boolean Contains(const T& item) = 0;

        /**
         * \brief Copies the elements of the ICollection<T> to an Array, starting at a particular Array index.
         * \param array The one-dimensional Array that is the destination of the elements copied from ICollection<T>. The Array
         *              must have zero-based indexing.
         * \param arrayIndex The zero-based index in array at which copying begins.
         */
        virtual void CopyTo(const T array[], const Int32& arrayIndex) = 0;

        /**
         * \brief Removes the first occurrence of a specific object from the ICollection<T>.
         * \param item The object to remove from the ICollection<T>.
         * \return true if item was successfully removed from the ICollection<T>; otherwise, false. This method also returns false
         *         if item is not found in the original ICollection<T>.
         */
        virtual Boolean Remove(const T& item) = 0;

#pragma endregion
    };
}
