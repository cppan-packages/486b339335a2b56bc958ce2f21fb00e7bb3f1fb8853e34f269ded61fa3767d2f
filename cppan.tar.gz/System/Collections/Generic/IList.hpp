/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include "../../DLL.hpp"
#include "../../Interface.hpp"

#include "../IEnumerable.hpp"

#include "ICollection.hpp"
#include "IEnumerable.hpp"

#pragma region Forward Declarations

namespace System
{
    struct Int32;
}

#pragma endregion

namespace System::Collections::Generic
{
    /**
     * \brief Represents a collection of objects that can be individually accessed by index.
     * \tparam T The type of elements in the list. 
     */
    template <typename T>
    interface DLLExport IList : ICollection<T>, Collections::IEnumerable, IEnumerable<T>
    {
    public:

#pragma region Public Virtual Instance Methods

        /**
        * \brief Determines the index of a specific item in the IList<T>.
        * \param item The object to locate in the IList<T>.
        * \return The index of item if found in the list; otherwise, -1.
        */
        virtual Int32 IndexOf(const T& item) = 0;

        /**
        * \brief Inserts an item to the IList<T> at the specified index.
        * \param index The zero-based index at which item should be inserted.
        * \param item The object to insert into the IList<T>.
        */
        virtual void Insert(const Int32& index, const T& item) = 0;

        /**
        * \brief Removes the IList<T> item at the specified index.
        * \param index The zero-based index of the item to remove.
        */
        virtual void RemoveAt(const Int32& index) = 0;

#pragma endregion

#pragma region Public Virtual Operators

        /**
         * \brief Gets or sets the element at the specified index.
         * \param index The zero-based index of the element to get or set.
         * \return The element at the specified index.
         */
        virtual T operator[](const Int32& index) = 0;

#pragma endregion

    protected:
        ~IList() = default;
    };
}
