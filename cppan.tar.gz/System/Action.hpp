/*
* Copyright (C) 2017 Gil Ferraz - All Rights Reserved
* You may use, distribute and modify this code under the
* terms of the Apache License, Version 2.0 license.
*
* This file is subject to the terms and conditions defined in
* file 'LICENSE.txt', which is part of this source code package.
* If you have no access to said file, please refer to:
* https://www.apache.org/licenses/LICENSE-2.0
*/

#pragma once

#include <functional>
#include "DLL.hpp"

namespace System
{
    /**
     * \brief Encapsulates a method that has specified parameters and does not return a value.
     * \tparam Args The type of the parameters of the method that this delegate encapsulates.
     */
    template <typename ...Args>
    class DLLExport Action final
    {
    public:
        typedef std::function<void(Args ...)> ActionType;

#pragma region Public Constructors

        Action(ActionType action);

#pragma endregion

#pragma region Public Destructor

        ~Action();

#pragma endregion

#pragma region Public Instance Methods

        void Invoke(Args&&... args);

#pragma endregion

    private:
        ActionType action;
    };

#pragma region Public Constructors

    template <typename ... Args>
    Action<Args...>::Action(ActionType action)
    {
        this->action = action;
    }

#pragma endregion

#pragma region Public Destructor

    template <typename ... Args>
    Action<Args...>::~Action()
    {
    }

#pragma endregion

#pragma region Public Instance Methods

    template <typename ... Args>
    void Action<Args...>::Invoke(Args&&... args)
    {
        if (&action != nullptr)
        {
            action(args...);
        }
    }

#pragma endregion
}
